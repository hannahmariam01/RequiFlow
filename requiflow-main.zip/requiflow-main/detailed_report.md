# RequiFlow — Detailed Frontend Application Report

> **AI-Powered Requirements Management Dashboard**
> Stack: **React 18 + Vite** (JSX layer) · **Vanilla JS `app.js`** (core logic) · **Vanilla CSS** (design system, 877 lines, 39 KB)

---

## 1. What the Frontend Is

RequiFlow is a **Single-Page Application** with **two parallel implementations** in the same repo:

| Layer | File | Role |
|---|---|---|
| **Vanilla JS engine** | `frontend/app.js` (712 lines) | Core logic: data store, DOM rendering, all user interactions |
| **React layer** | `frontend/src/` | JSX component wrappers over the same logic/data |
| **Design system** | `frontend/style.css` (877 lines, 39 KB) | All visual design — dark theme, animations, glassmorphism, responsive |
| **HTML shell** | `frontend/index.html` | Entry point, fonts, background decorations |
| **Dev server** | `frontend/vite.config.js` | Port 3000, auto-open browser |

The Vanilla JS `app.js` is the authoritative engine — it owns the data store, all DOM manipulation, view switching, toast alerts, animations, and event handling. The React components in `src/` mirror this logic using React state and JSX.

---

## 2. File Structure

```
frontend/
├── index.html              # HTML shell — fonts, background decorations, meta tags
├── app.js                  # Core Vanilla JS engine (712 lines)
├── style.css               # Global design system (877 lines, ~39 KB)
├── vite.config.js          # Vite: port 3000, auto-open browser
└── src/
    ├── main.jsx            # React DOM entry — mounts <App /> into #root
    ├── App.jsx             # Root component: global state + view router (414 lines)
    ├── components/         # 7 reusable UI components
    │   ├── Sidebar.jsx           (221 lines)
    │   ├── Topbar.jsx            (103 lines)
    │   ├── NotificationsPanel.jsx (36 lines)
    │   ├── NewProjectModal.jsx   (142 lines)
    │   ├── ToastContainer.jsx    (64 lines)
    │   ├── ProjectIcon.jsx       (54 lines)
    │   └── AnimatedCounter.jsx   (39 lines)
    └── views/              # 7 page-level view components
        ├── DashboardView.jsx     (242 lines)
        ├── ProjectsView.jsx      (70 lines)
        ├── ActiveProjectView.jsx (151 lines)
        ├── UserStoriesView.jsx   (47 lines)
        ├── DocumentsView.jsx     (55 lines)
        ├── AiAgentsView.jsx      (38 lines)
        └── SettingsView.jsx      (132 lines)
```

**Tech stack:**

| Tool | Version | Purpose |
|---|---|---|
| React | `^18.3.1` | UI rendering, state, hooks |
| Vite | `^5.3.1` | Dev server (port 3000) + bundler |
| `@vitejs/plugin-react` | `^4.3.1` | Fast Refresh, JSX transform |
| Vanilla CSS | — | All styling via `style.css` |

---

## 3. HTML Entry Point — `index.html`

```html
<title>RequiFlow – AI-Powered Requirements Dashboard</title>
<meta name="description" content="RequiFlow is an AI-powered requirements management platform...">
```

**Two fonts loaded via Google Fonts CDN:**
- **Inter** — weights 300, 400, 500, 600, 700, 800 → body text, labels, stats
- **Space Grotesk** — weights 400, 500, 600, 700 → headings, logo, stat values, page titles

**Three always-rendered background decoration elements:**

| Element | Class | What it does |
|---|---|---|
| Grid overlay | `.bg-grid` | Full-screen fixed 40×40px dot grid, shifts slowly via `gridShift` keyframe (60s loop) |
| Orb 1 | `.orb-1` | 600×600px radial blur blob, top-left, blue `rgba(79,140,255,0.10)` |
| Orb 2 | `.orb-2` | 500×500px radial blur blob, bottom-right, purple `rgba(168,85,247,0.08)` |
| Orb 3 | `.orb-3` | 400×400px radial blur blob, centered, cyan `rgba(0,212,255,0.06)` |

All orbs use the `orbFloat` keyframe (20s ease-in-out infinite, each with a phase offset via `animation-delay`) that slowly translates and scales them to create a living, breathing background.

---

## 4. Design System — `style.css` (877 lines)

### 4.1 CSS Custom Properties (`:root`)

**Background colours:**

| Variable | Value | Used for |
|---|---|---|
| `--bg-base` | `#050811` | Body background — near-black deep space |
| `--bg-surface` | `#0c1120` | Modal background, dropdown backgrounds |
| `--bg-card` | `rgba(15,22,42,0.85)` | All glassmorphic cards |
| `--bg-card-hover` | `rgba(20,30,58,0.95)` | Card hover states |
| `--bg-glass` | `rgba(255,255,255,0.03)` | Subtle glass fills (inputs, nav items, icon buttons) |
| `--bg-glass-hover` | `rgba(255,255,255,0.06)` | Hover on glass elements |

**Border colours:**

| Variable | Value | Used for |
|---|---|---|
| `--border-dim` | `rgba(99,120,180,0.12)` | Default subtle borders |
| `--border-bright` | `rgba(99,120,180,0.28)` | More visible borders |
| `--border-accent` | `rgba(79,140,255,0.35)` | Hover/focus accent border — electric blue tint |

**Accent colours:**

| Variable | Hex | Meaning |
|---|---|---|
| `--accent-blue` | `#4f8cff` | Primary — links, active states, E-Commerce |
| `--accent-cyan` | `#00d4ff` | Secondary highlight, link hover |
| `--accent-purple` | `#a855f7` | EdTech, generated status, doc activity |
| `--accent-green` | `#22d3a5` | Healthcare, approved status, agents active |
| `--accent-orange` | `#f59e0b` | Fintech, pending status, warnings |
| `--accent-red` | `#f43f5e` | Story high-priority, danger items, modal close hover |

**Text colours:**

| Variable | Value | Usage |
|---|---|---|
| `--text-primary` | `#e8edf8` | Main readable text |
| `--text-secondary` | `#7a8aaa` | Secondary descriptive text |
| `--text-muted` | `#4a5673` | Labels, timestamps, placeholders |
| `--text-accent` | `#4f8cff` | Accent text links |

**Layout tokens:**

| Variable | Value |
|---|---|
| `--sidebar-width` | `220px` |
| `--topbar-h` | `66px` |

**Border radii:**

| Variable | Value | Used for |
|---|---|---|
| `--radius-sm` | `6px` | Dropdown items, small buttons |
| `--radius-md` | `10px` | Inputs, nav items, icon buttons |
| `--radius-lg` | `14px` | Project cards, story cards, agent items |
| `--radius-xl` | `18px` | Stat cards, grid cards, panels, modal |

**Shadows:**

| Variable | Value |
|---|---|
| `--shadow-card` | `0 4px 24px rgba(0,0,0,0.45)` + inset top-edge highlight |
| `--shadow-glow` | `0 0 32px rgba(79,140,255,0.18)` — hover neon glow |
| `--shadow-modal` | `0 24px 80px rgba(0,0,0,0.7)` — deep modal shadow |

**Transitions:**

| Variable | Value |
|---|---|
| `--transition` | `200ms cubic-bezier(0.4,0,0.2,1)` — snappy standard |
| `--transition-slow` | `380ms cubic-bezier(0.4,0,0.2,1)` — modal entrance |

---

### 4.2 CSS Keyframe Animations

| `@keyframes` name | Duration | Effect |
|---|---|---|
| `gridShift` | 60s linear infinite | Background grid scrolls diagonally from `(0,0)` to `(40px,40px)` |
| `orbFloat` | 20s ease-in-out infinite | Orbs translate ±20–30px and scale ±0.05, creating slow drift |
| `spin` | 1s linear infinite | Refresh button SVG rotates 360° |
| `pulse` | 2s ease-in-out infinite | Agent active indicator dot breathes (opacity + scale 0.8→1) |
| `shimmer` | 2s ease-in-out infinite | Progress bar's `::after` shimmer fades in/out at 50% |
| `toastIn` | 200ms | Toast slides up from `translateY(10px)` + fades in |

---

### 4.3 Button System

Three distinct button styles:

**`.btn-primary`** — Gradient CTA button
- Background: `linear-gradient(135deg, #4f8cff, #6366f1)` (blue → indigo)
- Box-shadow: `0 4px 16px rgba(79,140,255,0.35)` + inner highlight
- Hover: lifts `translateY(-1px)`, glow shadow increases
- Has a `::before` overlay that fades in as a gloss effect on hover
- Active: snaps back `translateY(0)`

**`.btn-secondary`** — Ghost button
- Background: `var(--bg-glass)`, border: `var(--border-bright)`
- Hover: fills to `var(--bg-glass-hover)`, text brightens

**`.link-btn`** — Inline text link
- Borderless, accent-blue colour
- Hover: colour shifts to `--accent-cyan`

---

### 4.4 Status & Priority Colour System

**Project Status Badges (`.project-status`):**

| Class | Background | Text | Border |
|---|---|---|---|
| `.analyzed` | `rgba(79,140,255,0.15)` | `#4f8cff` blue | `rgba(79,140,255,0.25)` |
| `.approved` | `rgba(34,211,165,0.15)` | `#22d3a5` teal | `rgba(34,211,165,0.25)` |
| `.generated` | `rgba(168,85,247,0.15)` | `#a855f7` purple | `rgba(168,85,247,0.25)` |
| `.pending` | `rgba(245,158,11,0.15)` | `#f59e0b` amber | `rgba(245,158,11,0.25)` |

**Progress Bar Fills (`.progress-fill`):**

| Class | Gradient |
|---|---|
| `.analyzed` | `#4f8cff` → `#6366f1` |
| `.approved` | `#22d3a5` → `#10b981` |
| `.generated` | `#a855f7` → `#8b5cf6` |
| `.pending` | `#f59e0b` → `#f59e0b` |

All bars include a `::after` shimmer overlay (infinite pulsing `opacity` animation).

**Story Priority Badges (`.story-priority`):**

| Class | Background | Text |
|---|---|---|
| `.high` | `rgba(244,63,94,0.15)` | `#f43f5e` red |
| `.medium` | `rgba(245,158,11,0.15)` | `#f59e0b` amber |
| `.low` | `rgba(34,211,165,0.15)` | `#22d3a5` teal |

**Agent Avatar Colours (`.agent-avatar`):**

| Agent class | Gradient |
|---|---|
| `.ba` | `#4f8cff` → `#6366f1` (blue-indigo) |
| `.pm` | `#22d3a5` → `#10b981` (teal-green) |
| `.ux` | `#a855f7` → `#8b5cf6` (purple) |
| `.sa` | `#f59e0b` → `#f97316` (amber-orange) |

---

### 4.5 Project Icon Container Styling

| Class | Background | Border | SVG stroke |
|---|---|---|---|
| `.project-icon.ecommerce` | `rgba(79,140,255,0.2)` gradient | `rgba(79,140,255,0.25)` | `#4f8cff` |
| `.project-icon.healthcare` | `rgba(34,211,165,0.2)` gradient | `rgba(34,211,165,0.25)` | `#22d3a5` |
| `.project-icon.edtech` | `rgba(168,85,247,0.2)` gradient | `rgba(168,85,247,0.25)` | `#a855f7` |
| `.project-icon.fintech` | `rgba(245,158,11,0.2)` gradient | `rgba(245,158,11,0.25)` | `#f59e0b` |

On card hover: the icon container does `scale(1.08) rotate(-3deg)` — a subtle playful tilt.

---

### 4.6 Card Visual Details

**Stat cards (`.stat-card`):**
- `::before` top-edge highlight: 1px gradient line `transparent → rgba(79,140,255,0.3) → transparent`
- Warning stat card: amber gradient `rgba(245,158,11,0.4)` top edge
- Bottom-right corner: `.stat-glow` — 80×80px blurred radial gradient orb

**Project list cards (`.project-card`):**
- Left-edge `::before`: 3px vertical gradient accent bar (`--accent-blue` → `--accent-purple`), `opacity:0`, slides to `opacity:1` on hover
- Hover: translates `translateX(3px)` (subtle slide right)
- Focus-visible (keyboard): same effects as hover

**Project grid cards (`.project-grid-card`):**
- Top-edge `::before` gradient highlight line
- Hover: `translateY(-3px)` lift + `--shadow-glow` neon glow

---

### 4.7 Special UI Element Details

**Search input expand-on-focus:**
- Default width: `220px`
- On `:focus`: expands to `260px`, border becomes `--border-accent`, background shifts to `rgba(79,140,255,0.06)`, 3px outer glow ring

**Toggle switch (`.toggle`):**
- 40×22px custom CSS toggle
- Off state: muted grey thumb, glass track
- On state: gradient blue-indigo track with box-shadow glow, white thumb slides right `translateX(18px)`

**Notification bell badge (`.notif-dot`):**
- 16×16px circle, gradient red `#f43f5e → #ff6b6b`
- Box-shadow: `0 0 8px rgba(244,63,94,0.5)` — red neon glow
- Shows the unread count number

**Modal overlay:**
- Backdrop: `rgba(0,0,0,0.7)` + `backdrop-filter: blur(10px)` — true frosted-glass dimming
- Modal box enters: slides up from `translateY(20px) scale(0.97)` → `translateY(0) scale(1)` over `380ms`
- `::before` top-edge: animated blue gradient line

**User dropdown (`.user-dropdown`):**
- Hidden: `opacity:0; visibility:hidden; transform:translateY(8px)`
- Open: `opacity:1; visibility:visible; transform:translateY(0)` — slides up into view
- Danger "Sign out" item turns red on hover

---

### 4.8 Responsive Breakpoints

| Breakpoint | Changes |
|---|---|
| `≤ 1100px` | Stats grid goes 4→2 columns; bottom row (activity + agents) stacks to 1 column |
| `≤ 760px` | Sidebar hides entirely; stats 2 columns; view padding reduced; topbar padding reduced |
| `≤ 520px` | Stats go single column |

---

## 5. Vanilla JS Engine — `app.js` (712 lines)

> The core DOM-based engine. All data, rendering, interactions, and animations live here.

### 5.1 Data Store (`store` object)

A single global `store` object serves as the in-memory database. All functions read and mutate it directly — no state manager, resets on page reload.

```js
const store = {
  projects: [ /* 4 objects */ ],
  userStories: [ /* 8 objects */ ],
  documents: [ /* 7 objects */ ],
  agents: [ /* 4 objects */ ],
  activeProjectId: 'ecommerce',
  notifications: 2,
};
```

**Projects (4 seeded):**

| id | name | type | status | progress |
|---|---|---|---|---|
| `ecommerce` | E-Commerce Platform | platform | analyzed | 72% |
| `healthcare` | Healthcare Portal | web | approved | 95% |
| `edtech` | EdTech LMS | platform | generated | 60% |
| `fintech` | Fintech App | mobile | pending | 30% |

Fields: `id`, `name`, `desc`, `type`, `status`, `progress`, `icon`, `updatedLabel`, `stories`, `docs`

**User Stories (8 seeded):**

| id | projectId | Role | Priority |
|---|---|---|---|
| US-001 | ecommerce | buyer | high |
| US-002 | ecommerce | seller | medium |
| US-003 | healthcare | patient | high |
| US-004 | healthcare | doctor | high |
| US-005 | edtech | student | medium |
| US-006 | edtech | instructor | low |
| US-007 | fintech | user | high |
| US-008 | fintech | user | medium |

Story text uses `<strong>` HTML tags for the user role — rendered as `innerHTML`.

**Documents (7 seeded):**

| id | name | fullName | projectId | icon | size |
|---|---|---|---|---|---|
| doc-1 | BRD | Business Requirements Document | ecommerce | 📄 | 2.4 MB |
| doc-2 | SRS | Software Requirements Specification | ecommerce | 📋 | 1.8 MB |
| doc-3 | User Stories | User Story Document | ecommerce | 📝 | 540 KB |
| doc-4 | BRD | Business Requirements Document | healthcare | 📄 | 1.6 MB |
| doc-5 | SRS | Software Requirements Specification | healthcare | 📋 | 1.1 MB |
| doc-6 | BRD | Business Requirements Document | edtech | 📄 | 980 KB |
| doc-7 | User Stories | User Story Document | fintech | 📝 | 320 KB |

**AI Agents (4 seeded):**

| id | initials | name | role | status | task |
|---|---|---|---|---|---|
| ba | BA | Business Analyst | Requirements Analysis & Elicitation | active | Analyzing E-Commerce requirements |
| pm | PM | Product Manager | Backlog & Prioritization | active | Reviewing EdTech user stories |
| ux | UX | UX Researcher | User Research & Prototyping | standby | null |
| sa | SA | Solution Architect | Technical Architecture Design | standby | null |

---

### 5.2 Icon System

**`PROJECT_ICONS` map** — holds inline SVG strings keyed by project type:
- `ecommerce` → shopping cart SVG (cart body + 2 wheel circles)
- `healthcare` → EKG / heartbeat line SVG
- `edtech` → graduation cap (mortarboard) SVG
- `fintech` → dollar sign SVG (vertical line + S-curve path)

**`ICON_STROKE_COLOR` map:**
```js
ecommerce: '#4f8cff'  healthcare: '#22d3a5'  edtech: '#a855f7'  fintech: '#f59e0b'
```

**`iconSvg(iconKey)`** — injects the correct colour by replacing `stroke="currentColor"` in the SVG string with the mapped hex value.

---

### 5.3 View Switching — `switchView(viewId, navEl)`

The core routing function — called for every navigation action.

**Steps executed in order:**
1. Remove `.active` from all `.view` elements (hides all views)
2. Remove `.active` from all `.nav-item` elements
3. Add `.active` to `#view-[viewId]` (shows target view)
4. Add `.active` to the `navEl` passed in
5. Update `#page-title` text from a titles map
6. Call the appropriate render function:
   - `projects` → `renderProjectsGrid()`
   - `active-project` → `renderActiveProject()`
   - `user-stories` → `renderUserStories()`
   - `documents` → `renderDocuments()`
   - `ai-agents` → `renderAgentsGrid()`
   - `settings` → `renderSettings()`
7. `closeNotificationsPanel()` + `closeUserMenu()` — panels close on every nav

---

### 5.4 `renderProjectsGrid()`

Targets `#projects-grid`. Rebuilds `innerHTML` by mapping `store.projects` through a template literal. Each card has `onclick="openProject('${p.id}')"` and `onkeydown` for Enter key accessibility.

---

### 5.5 `renderActiveProject()`

Targets `#active-project-container`. Resolves project from `store.activeProjectId`.

**Template renders in order:**
1. **Hero block**: project icon (52×52px) + name + desc + status badge + progress bar (8px height) + 3-column stats row (story count, doc count, last updated)
2. **User Stories section**: section label + `storyCardHTML()` for each filtered story — empty state if none
3. **Documents section**: label + Export button + `docCardHTML()` for each filtered doc
4. **Action bar**: "Generate Stories with AI" + "← All projects"

---

### 5.6 `storyCardHTML(s)`

Returns HTML with:
- `.story-id` — e.g. `US-001` (blue, 11px, Space Grotesk monospace)
- `.story-text` — story text as `innerHTML` (preserves `<strong>` role tags)
- `.story-tags` — each tag as a glass pill `<span class="story-tag">`
- `.story-priority` — colour-coded priority badge

---

### 5.7 `generateStories()`

```
1. showToast('info', '🤖 AI is generating new user stories…')
2. setTimeout(1800ms):
   a. Creates new story: id='US-00N', projectId=activeProjectId,
      text="As a <strong>user</strong>, I want to receive AI-powered suggestions…",
      tags=['AI','Suggestions','UX'], priority='medium'
   b. store.userStories.push(newStory)
   c. animateCount() on #stat-user-stories .stat-value
   d. renderUserStories()  ← re-renders DOM
   e. showToast('success', '✅ New user story generated!')
```

---

### 5.8 `docCardHTML(d)`

Returns HTML with:
- `onclick="downloadDoc('${d.id}')"` on the whole card
- `.doc-icon` — emoji at 32px
- `.doc-name` — short name (BRD / SRS / User Stories)
- `.doc-proj` — resolved project name + date
- `.doc-dl-btn` — "⬇ Download (X MB)" button with `event.stopPropagation()`

---

### 5.9 `exportDocument()`

```
1. showToast('info', '📤 Exporting document…')
2. setTimeout(1500ms):
   a. Creates: id='doc-N', name='SRS', icon='📋', size='1.2 MB', date='Just now'
   b. store.documents.push(newDoc)
   c. animateCount() on #stat-docs .stat-value
   d. renderDocuments()  ← re-renders DOM
   e. showToast('success', '✅ Document exported successfully!')
```

---

### 5.10 `downloadDoc(docId)` & `downloadProject(projId)`

Both: look up item in store → `showToast('success', '⬇ Downloading [name]…')`. No actual file download — UI confirmation only.

---

### 5.11 `renderAgentsGrid()`

Targets `#agents-grid-view`. Maps `store.agents` to cards:
- 56×56px circle avatar with initials + colour class
- Agent name, role
- Status badge: active = pulsing live dot + task text; standby = muted text

---

### 5.12 `toggleAgentStatus(agentId)`

```
1. Find agent by id in store.agents
2. If active:
   - status = 'standby', task = null
   - showToast('info', '[name] set to Standby')
3. If standby:
   - status = 'active', task = 'Analyzing requirements'
   - showToast('success', '[name] is now Active')
4. renderAgentsGrid()      ← re-renders AI Agents page
5. renderAgentsOnCall()    ← re-renders dashboard's agent panel (if visible)
```

**`renderAgentsOnCall()`** targets `#agents-list` on the Dashboard — rebuilds compact list items with avatar, name, status text, and indicator dot.

---

### 5.13 `renderSettings()`

Writes three settings sections as HTML. Each `<label class="toggle">` has inline `onchange="showToast(...)"`. No persistent settings state — resets on page reload.

---

### 5.14 `openProject(projId)`

```
1. store.activeProjectId = projId
2. showToast('info', 'Opening [name]…')
3. switchView('active-project', #nav-active-project)
   → calls renderActiveProject() for the chosen projId
```

---

### 5.15 New Project Modal Functions

**`openNewProjectModal()`**
- Adds `.open` class to `#new-project-modal`, sets `aria-hidden="false"`
- Calls `document.getElementById('proj-name').focus()` — auto-focuses the name field
- Registers `handleModalKeydown` listener (Escape to close)

**`closeNewProjectModal()`**
- Removes `.open` class, resets form via `.reset()`
- Removes Escape key listener

**`handleModalKeydown(e)`** — fires `closeNewProjectModal()` if `e.key === 'Escape'`

**Overlay click to close:**
```js
document.getElementById('new-project-modal').addEventListener('click', function(e) {
  if (e.target === this) closeNewProjectModal();
});
```

**`submitNewProject(e)`:**
```
1. e.preventDefault()
2. Read: name, desc, type from form inputs
3. Validate: if name is empty, return
4. Build project: id='proj-'+Date.now(), status='pending', progress=0
5. store.projects.unshift(newProject)  ← adds to FRONT of array
6. closeNewProjectModal() + form reset
7. updateProjectBadge() ← updates sidebar nav count badge
8. animateCount() on #stat-total-projects
9. showToast('success', '🚀 "[name]" created! AI is analyzing…')
10. setTimeout(3000ms):
    a. status = 'analyzed', progress = random 20–50
    b. showToast('info', '🤖 AI completed initial analysis for "[name]"')
    c. If projects view active: renderProjectsGrid()
```

**Icon mapping for new projects:**

| type value | icon assigned |
|---|---|
| `web` | `ecommerce` |
| `mobile` | `fintech` |
| `api` | `healthcare` |
| `platform` | `edtech` |
| `other` | `edtech` |

---

### 5.16 `handleRefresh()`

```
1. refresh-btn.classList.add('spin')  → CSS infinite rotation on SVG
2. showToast('info', '🔄 Refreshing dashboard…')
3. setTimeout(1200ms):
   a. btn.classList.remove('spin')
   b. showToast('success', '✅ Dashboard refreshed!')
```

---

### 5.17 Notifications System

**`toggleNotifications()`** — opens or closes the panel. If opening, closes the user menu.

**`closeNotificationsPanel()`** — removes `.open`, sets `aria-hidden="true"`.

**`clearNotifications()`** (Mark all read):
```
1. store.notifications = 0
2. Hides .notif-dot badge
3. All .notif-item.unread: removes .unread, adds .read to inner dot
4. showToast('success', '✅ All notifications marked as read')
```

---

### 5.18 User Menu

**`toggleUserMenu()`** — opens or closes. If opening, closes the notifications panel, sets `aria-expanded="true"`.

**`closeUserMenu()`** — removes `.open`, sets `aria-expanded="false"`.

---

### 5.19 Search — `handleSearch(query)` with Debounce

```js
let searchTimeout = null;
function handleSearch(query) {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {  // 200ms debounce
    const q = query.toLowerCase().trim();
    if (!q) {
      document.querySelectorAll('.project-card').forEach(c => c.style.display = '');
      return;
    }
    // Filter dashboard list cards
    document.querySelectorAll('.project-card').forEach(card => {
      const name = card.querySelector('.project-name')?.textContent.toLowerCase();
      const desc = card.querySelector('.project-desc')?.textContent.toLowerCase();
      card.style.display = (name.includes(q) || desc.includes(q)) ? '' : 'none';
    });
    // Filter projects grid cards
    document.querySelectorAll('.project-grid-card').forEach(card => {
      const name = card.querySelector('.pgc-name')?.textContent.toLowerCase();
      const desc = card.querySelector('.pgc-desc')?.textContent.toLowerCase();
      card.style.display = (name.includes(q) || desc.includes(q)) ? '' : 'none';
    });
  }, 200);
}
```

Filtering fires **200ms after the user stops typing** — prevents excessive DOM manipulation on every keystroke.

---

### 5.20 Toast System — `showToast(type, message)`

Fully dynamic — creates a real DOM element each call:

```
1. document.createElement('div') with class 'toast [type]'
2. Icons map: success=checkmark SVG, error=X SVG, info=circle-i SVG
3. toast.innerHTML = icon + '<span>[message]</span>'
4. container.appendChild(toast)     → enters via toastIn CSS animation
5. setTimeout(3500ms):
   a. style.animation = 'toastIn 200ms reverse forwards'  → exit animation
   b. setTimeout(200ms): toast.remove()  → clean DOM removal
```

**Toast types:**

| type | SVG icon | Border colour |
|---|---|---|
| `success` | Checkmark polyline | `rgba(34,211,165,0.3)` teal |
| `error` | X mark (two lines) | `rgba(244,63,94,0.3)` red |
| `info` | Circle with `i` | `rgba(79,140,255,0.3)` blue |

---

### 5.21 Animated Counter — `animateCount(el, from, to)`

```js
function animateCount(el, from, to) {
  const duration = 800;
  const start = performance.now();
  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);  // cubic ease-out
    el.textContent = Math.round(from + (to - from) * eased);
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}
```

Used on stat cards when new items are added (projects, stories, documents).

---

### 5.22 Progress Bar Load Animation — `animateProgressBars()`

```js
function animateProgressBars() {
  document.querySelectorAll('.progress-fill').forEach(bar => {
    const targetWidth = bar.style.width;  // capture target
    bar.style.width = '0%';              // reset to 0
    requestAnimationFrame(() => {
      bar.style.transition = 'width 1.2s cubic-bezier(0.4,0,0.2,1)';
      bar.style.width = targetWidth;     // animate to target
    });
  });
}
```

Called `300ms` after `DOMContentLoaded` — bars animate in rather than appearing instantly at full width.

---

### 5.23 Global Keyboard Shortcut

```js
document.addEventListener('keydown', function(e) {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    document.getElementById('global-search').focus();
  }
});
```

`Ctrl+K` / `⌘K` focuses the search input from anywhere in the app.

---

### 5.24 Outside-Click Handler (Global)

```js
document.addEventListener('click', function(e) {
  if (!notifPanel.contains(e.target) && !notifBtn.contains(e.target)) closeNotificationsPanel();
  if (!userMenu.contains(e.target) && !userBtn.contains(e.target)) closeUserMenu();
});
```

Fires on every document click. Uses `.contains()` to detect if the click was inside the panel/button — closes if outside both.

---

### 5.25 Initialization — `DOMContentLoaded`

```js
document.addEventListener('DOMContentLoaded', function () {
  // 1. Animate stat counters with data-target attributes (0 → target)
  document.querySelectorAll('.stat-value[data-target]').forEach(el => {
    animateCount(el, 0, parseInt(el.getAttribute('data-target')));
  });
  // 2. Animate progress bars after 300ms delay
  setTimeout(animateProgressBars, 300);
  // 3. Set dashboard as the default active view
  switchView('dashboard', document.getElementById('nav-dashboard'));
});
```

---

## 6. React Component Tree (`src/`)

```
<App>  (global state + handler functions)
 ├── <Sidebar>                    navigation rail
 ├── <main>
 │    ├── <Topbar>                search, refresh, bell, new project
 │    ├── <NotificationsPanel>    slide-in dropdown
 │    └── {renderView()}          one of 7 views rendered by currentView state
 │         ├── <DashboardView>
 │         │    ├── <AnimatedCounter> (×4 stat cards)
 │         │    └── <ProjectIcon>     (×4 project cards)
 │         ├── <ProjectsView>
 │         │    └── <ProjectIcon>
 │         ├── <ActiveProjectView>
 │         │    └── <ProjectIcon>
 │         ├── <UserStoriesView>
 │         ├── <DocumentsView>
 │         ├── <AiAgentsView>
 │         └── <SettingsView>
 ├── <NewProjectModal>
 └── <ToastContainer>
      └── <ToastItem> (×N, one per active toast)
```

---

## 7. React Component Reference

### 7.1 `App.jsx` — Global State

| State variable | Default | Type |
|---|---|---|
| `projects` | 4 seeded | `Array<Project>` |
| `userStories` | 8 seeded | `Array<Story>` |
| `documents` | 7 seeded | `Array<Doc>` |
| `agents` | 4 seeded | `Array<Agent>` |
| `activeProjectId` | `'ecommerce'` | `string` |
| `currentView` | `'dashboard'` | `string` |
| `searchQuery` | `''` | `string` |
| `userMenuOpen` | `false` | `boolean` |
| `notificationsOpen` | `false` | `boolean` |
| `newProjectModalOpen` | `false` | `boolean` |
| `toasts` | `[]` | `Array<Toast>` |
| `notificationsList` | 3 items | `Array<Notif>` |

**Derived:** `unreadNotificationsCount = notificationsList.filter(n => n.unread).length`

**Handler functions exposed as props:**

| Handler | Effect |
|---|---|
| `handleViewChange(viewId)` | Sets `currentView`, closes open dropdowns |
| `handleOpenProject(projId)` | Sets `activeProjectId`, navigates to `active-project`, shows info toast |
| `handleNewProjectSubmit(data)` | Adds project (pending, 0%) → 3s → promotes to analyzed (20–50%) |
| `handleGenerateStories()` | 1.8s → appends new story, updates stat counter |
| `handleExportDocument()` | 1.5s → appends new SRS doc, updates stat counter |
| `handleDownloadDocument(docId)` | Shows ⬇ downloading toast |
| `handleDownloadProject(projId)` | Shows ⬇ preparing toast |
| `handleToggleAgentStatus(agentId)` | Flips agent active ↔ standby, updates task |
| `handleRefresh()` | Info toast → 1.2s → success toast |
| `handleClearNotifications()` | Marks all `unread: false` |
| `showToast(type, message)` | Pushes new toast to queue |

**Outside-click `useEffect`** — global `document.addEventListener('click', ...)` closes notifications panel and user menu when clicking outside. Cleanup removes listener on unmount.

---

### 7.2 `Sidebar.jsx`

**Props:** `currentView`, `onViewChange`, `projectsCount`, `userMenuOpen`, `setUserMenuOpen`, `closeNotifications`

**Navigation sections:**

| Section | Item | viewId |
|---|---|---|
| Overview | Dashboard | `dashboard` |
| Overview | Projects (with count badge) | `projects` |
| Workspace | Active Project | `active-project` |
| Workspace | User Stories | `user-stories` |
| Workspace | Documents | `documents` |
| Agents | AI Agents | `ai-agents` |
| Agents | Settings | `settings` |

Active nav item styling:
- Background gradient: `rgba(79,140,255,0.15) → rgba(168,85,247,0.1)`
- Text: `--accent-blue`
- Left `::before` bar: 3px gradient (blue → purple) with neon glow box-shadow

**User profile footer:**
- Avatar "AK" — 32px circle, gradient blue-purple
- Name: "Arjun Kumar" | Role: "Product Manager"
- Three-dots button → opens dropdown
- Dropdown items: Profile → Settings, Settings → Settings, divider, red "Sign out"

---

### 7.3 `Topbar.jsx`

**Props:** `pageTitle`, `searchVal`, `onSearchChange`, `onRefresh`, `notificationsCount`, `onNotificationsToggle`, `onNewProjectClick`

**Internal state:** `isRefreshing` (boolean), `searchInputRef`

- **Page title `<h1>`**: Space Grotesk 20px, gradient text
- **Search `<input>`**: expands 220px→260px on focus, `Ctrl+K`/`⌘K` shortcut via `useEffect`
- **Refresh button**: `isRefreshing` adds `.spin` → CSS infinite SVG rotation, resets after 1200ms
- **Bell button**: conditionally renders red `<span class="notif-dot">` with count
- **"+ New project" button**: primary gradient button

---

### 7.4 `NotificationsPanel.jsx`

**Props:** `isOpen`, `notificationsList`, `onClearAll`

CSS transition: hidden (`translateY(-8px) scale(0.98)`) → open (`translateY(0) scale(1)`).

Unread items: `rgba(79,140,255,0.06)` blue-tint background with blue left dot (glowing).
Read items: grey dot, no background tint.

**Initial 3 notifications:**

| # | Text | Status |
|---|---|---|
| 1 | Pending approval for **Healthcare Portal** | 🔵 Unread |
| 2 | 3 clarification questions on **Fintech App** | 🔵 Unread |
| 3 | BRD exported for **EdTech LMS** | ⚪ Read |

---

### 7.5 `NewProjectModal.jsx`

**Props:** `isOpen`, `onClose`, `onSubmit`

**Internal state:** `name`, `desc`, `type` (`'web'`), `priority` (`'medium'`)

- Returns `null` when `!isOpen` (conditionally mounted)
- `useEffect` resets fields + auto-focuses name input (50ms delay via `setTimeout`)
- `useEffect` registers/deregisters Escape key listener
- Overlay click: `if (e.target === e.currentTarget) onClose()`

**Form fields:**

| Field | Type | Required |
|---|---|---|
| Project Name | `<input type="text">` | ✅ Yes |
| Description | `<textarea rows=3>` | No |
| Project Type | `<select>` | No — Web App, Mobile App, API/Backend, Platform, Other |
| Priority | `<select>` | No — High, Medium, Low |

---

### 7.6 `ToastContainer.jsx` & `ToastItem`

**`ToastItem` internal state:** `isExiting` (boolean)

**Lifecycle:**
```
Mount → toastIn CSS animation (slide up + fade in)
At 3300ms: setIsExiting(true) → reverse animation (fade out + slide down)
At 3500ms: onRemove(toast.id) → parent removes from array → React unmounts
```

Toast IDs: `'toast-' + Date.now() + Math.random().toString(36).substr(2, 5)` — unique even for simultaneous toasts.

---

### 7.7 `ProjectIcon.jsx`

**Props:** `name`, `color` (optional override)

Default stroke: `ICON_STROKE_COLOR[name] || '#4f8cff'`

| `name` | Shape | Default stroke |
|---|---|---|
| `ecommerce` | Shopping cart + 2 circles | `#4f8cff` |
| `healthcare` | EKG waveform | `#22d3a5` |
| `edtech` | Mortarboard cap | `#a855f7` |
| `fintech` | Dollar sign | `#f59e0b` |
| *(default)* | Circle with plus | `#4f8cff` |

All SVGs: 20×20px, `fill="none"`, `strokeWidth="2"`, rounded linecaps.

---

### 7.8 `AnimatedCounter.jsx`

**Props:** `value`, `duration` (default: 800ms)

**Internal state:** `count`, `prevValueRef`

Cubic ease-out formula: `eased = 1 - (1 - progress)³`

Animates from previous value to new value using `requestAnimationFrame`. Cleanup cancels animation on unmount. Used in all 4 dashboard stat cards.

---

## 8. View-by-View Output Details

### 8.1 Dashboard — `DashboardView.jsx`

**Stats grid (4-column):**

| Card id | Label | Value | Delta |
|---|---|---|---|
| `#stat-total-projects` | Total projects | `projects.length` | "2 this month" ↑ green |
| `#stat-user-stories` | User stories generated | `34 + userStories.length` | "18 this week" ↑ green |
| `#stat-docs` | Documents exported | `documents.length` | "BRD, SRS, User Stories" muted |
| `#stat-approvals` | Pending approvals | pending count + 1 | "Needs review" ⚠ amber |

**Recent Projects list** — shows first 4 only (`.slice(0,4)`). EdTech uniquely renders a green **download button** instead of the arrow button (hardcoded `if (p.id === 'edtech')`).

**Recent Activity — 4 hardcoded events:**

| Type | Event | Time | Icon |
|---|---|---|---|
| `ai` | AI Analysis completed — E-Commerce Platform | 2 hours ago | Lock icon |
| `approved` | Approved Healthcare Portal requirements | Yesterday, 3:40 PM | Checkmark |
| `doc` | BRD exported — EdTech LMS | 2 days ago | File icon |
| `warn` | 3 clarification questions — Fintech App | 3 days ago | Alert circle |

**AI Agents on Call** — "Live" badge with pulsing green dot. Active agents get `.active-agent` blue-tint background + pulsing indicator.

---

### 8.2 Projects View — `ProjectsView.jsx`

Live filter: `projects.filter(p => p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q))`

Grid: `repeat(auto-fill, minmax(280px, 1fr))`. Empty state spans full grid width.

---

### 8.3 Active Project View — `ActiveProjectView.jsx`

Progress bar height: **8px** (vs. 4px in list view).

Stats row: 3-column grid — story count, doc count, last updated.

Fallback if no project found:
```jsx
<p>No active project. Please select or create a project first.</p>
```

---

### 8.4 User Stories View — `UserStoriesView.jsx`

Shows **all stories across all projects** — not filtered. Empty state: centered, 40px vertical padding.

---

### 8.5 Documents View — `DocumentsView.jsx`

Grid: `repeat(auto-fill, minmax(220px, 1fr))`. Resolves project name via `projects.find()`, shows "Unknown Project" if not found. Download button goes full-width gradient blue on hover.

---

### 8.6 AI Agents View — `AiAgentsView.jsx`

Grid: `repeat(auto-fill, minmax(240px, 1fr))`. Cards are text-centered. Avatar: 56×56px circle (larger than dashboard's 32×32). Active badge has pulsing live dot.

---

### 8.7 Settings View — `SettingsView.jsx`

**Internal React state (resets on unmount):**

| Setting | Default |
|---|---|
| Email notifications | ✅ ON |
| AI analysis alerts | ✅ ON |
| Weekly digest | ❌ OFF |
| Auto-generate user stories | ✅ ON |
| Smart document suggestions | ✅ ON |
| Two-factor authentication | ❌ OFF |

Max-width: 640px. Each section is a glass card. Last row in each section has no bottom border.

---

## 9. Complete User Action → Output Reference

| # | User Action | Immediate Output | Delayed Output |
|---|---|---|---|
| 1 | Page loads | Dashboard renders; stat cards count up from 0; progress bars slide in (300ms delay) | — |
| 2 | Hover project card | Left accent bar appears, card slides right 3px, glow shadow, icon tilts `scale(1.08) rotate(-3deg)` | — |
| 3 | Click project card | Info toast "Opening [name]…", navigates to Active Project view | — |
| 4 | Click "New project" | Modal fades + scales in, name field auto-focused | — |
| 5 | Press Escape (modal open) | Modal closes, form resets | — |
| 6 | Click modal backdrop | Modal closes, form resets | — |
| 7 | Submit modal (valid name) | Project added (pending, 0%), nav badge +1, stat animates, 🚀 toast | 3000ms → analyzed, 20–50%, 🤖 toast; Projects grid re-renders if visible |
| 8 | Submit modal (empty name) | No action, form validates silently | — |
| 9 | Click "Generate with AI" | 🤖 info toast | 1800ms → new story appended, stories stat animates, ✅ toast |
| 10 | Click "Export" | 📤 info toast | 1500ms → new SRS doc appended, docs stat animates, ✅ toast |
| 11 | Click document card | ✅ toast "⬇ Downloading [name]…" | — |
| 12 | Click doc download button | Same ✅ toast (stopPropagation prevents double fire) | — |
| 13 | Click EdTech download (Dashboard) | ✅ toast "⬇ Preparing EdTech LMS documents…" | — |
| 14 | Click active agent | Status → standby, task cleared, blue tint removed, info toast | — |
| 15 | Click standby agent | Status → active, task set, blue tint applied, ✅ toast | — |
| 16 | Toggle settings switch | Switch slides, info toast "[setting] updated" | — |
| 17 | Click "Edit profile" | Info toast "Profile editing coming soon" | — |
| 18 | Click refresh | SVG spin starts, 🔄 info toast | 1200ms → spin stops, ✅ toast |
| 19 | Click bell icon | Notifications panel slides in, user menu closes | — |
| 20 | Click "Mark all read" | Unread items lose blue tint, dots turn grey, badge hides, ✅ toast | — |
| 21 | Click outside panel | Global listener closes panel | — |
| 22 | Type in search bar | 200ms debounce → project cards show/hide by name+desc | — |
| 23 | Clear search | All cards restored to visible | — |
| 24 | Press Ctrl+K / ⌘K | Search input focused, width expands to 260px | — |
| 25 | Click user profile | User dropdown slides up, notifications panel closes | — |
| 26 | Click "Sign out" | Browser `alert('Signing out...')` | — |
| 27 | Click "View all →" | Navigates to Projects view | — |
| 28 | Click "← All projects" | Navigates to Projects view | — |
| 29 | Keyboard Enter on card | Same as click (keyboard accessibility) | — |
| 30 | Keyboard Enter on agent | Toggles agent status (keyboard accessibility) | — |

---

## 10. Running the Frontend

```powershell
# From the frontend folder
cd c:\Users\Hannah\Downloads\requiflow\frontend

# Install dependencies (first time only)
npm install

# Start dev server → auto-opens http://localhost:3000
npm run dev

# Build for production
npm run build   # outputs to frontend/dist/
```

**Vite config** (`vite.config.js`):
```js
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,    // fixed port
    open: true,    // auto-opens browser tab on start
  },
});
```
