/* ═══════════════════════════════════════════════════════════════
   RequiFlow – App Logic (app.js)
   All dashboard functionality: navigation, modals, data, search
   ═══════════════════════════════════════════════════════════════ */

'use strict';

// ════════════════════════════ DATA STORE ════════════════════════════
const store = {
  projects: [
    {
      id: 'ecommerce',
      name: 'E-Commerce Platform',
      desc: 'Multi-vendor marketplace with AI recommendations',
      type: 'platform',
      status: 'analyzed',
      progress: 72,
      icon: 'ecommerce',
      updatedLabel: 'Updated 2h ago',
      stories: 18,
      docs: 3,
    },
    {
      id: 'healthcare',
      name: 'Healthcare Portal',
      desc: 'Patient records and teleconsultation system',
      type: 'web',
      status: 'approved',
      progress: 95,
      icon: 'healthcare',
      updatedLabel: 'Updated yesterday',
      stories: 12,
      docs: 2,
    },
    {
      id: 'edtech',
      name: 'EdTech LMS',
      desc: 'Learning management system with video delivery',
      type: 'platform',
      status: 'generated',
      progress: 60,
      icon: 'edtech',
      updatedLabel: '2 days ago',
      stories: 8,
      docs: 1,
    },
    {
      id: 'fintech',
      name: 'Fintech App',
      desc: 'Digital banking with real-time payment processing',
      type: 'mobile',
      status: 'pending',
      progress: 30,
      icon: 'fintech',
      updatedLabel: '3 days ago',
      stories: 4,
      docs: 1,
    },
  ],

  userStories: [
    { id: 'US-001', projectId: 'ecommerce', text: 'As a <strong>buyer</strong>, I want to browse products by category so that I can find items quickly.', tags: ['E-Commerce', 'Browse', 'UX'], priority: 'high' },
    { id: 'US-002', projectId: 'ecommerce', text: 'As a <strong>seller</strong>, I want to list products with AI-generated descriptions so that I can save time.', tags: ['E-Commerce', 'AI', 'Seller'], priority: 'medium' },
    { id: 'US-003', projectId: 'healthcare', text: 'As a <strong>patient</strong>, I want to book a teleconsultation so that I can consult a doctor from home.', tags: ['Healthcare', 'Booking', 'Telehealth'], priority: 'high' },
    { id: 'US-004', projectId: 'healthcare', text: 'As a <strong>doctor</strong>, I want to view patient records before a session so that I can prepare properly.', tags: ['Healthcare', 'Records', 'Doctor'], priority: 'high' },
    { id: 'US-005', projectId: 'edtech', text: 'As a <strong>student</strong>, I want to resume a video lecture from where I left off so that I can learn at my own pace.', tags: ['EdTech', 'Video', 'UX'], priority: 'medium' },
    { id: 'US-006', projectId: 'edtech', text: 'As an <strong>instructor</strong>, I want to upload course materials so that students can access them anytime.', tags: ['EdTech', 'Content', 'Instructor'], priority: 'low' },
    { id: 'US-007', projectId: 'fintech', text: 'As a <strong>user</strong>, I want to send money instantly to contacts so that I can pay quickly and securely.', tags: ['Fintech', 'Payments', 'UX'], priority: 'high' },
    { id: 'US-008', projectId: 'fintech', text: 'As a <strong>user</strong>, I want to receive real-time notifications for transactions so that I can track my spending.', tags: ['Fintech', 'Notifications', 'Security'], priority: 'medium' },
  ],

  documents: [
    { id: 'doc-1', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'ecommerce', icon: '📄', size: '2.4 MB', date: '2h ago' },
    { id: 'doc-2', name: 'SRS', fullName: 'Software Requirements Specification', projectId: 'ecommerce', icon: '📋', size: '1.8 MB', date: '2h ago' },
    { id: 'doc-3', name: 'User Stories', fullName: 'User Story Document', projectId: 'ecommerce', icon: '📝', size: '540 KB', date: '2h ago' },
    { id: 'doc-4', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'healthcare', icon: '📄', size: '1.6 MB', date: 'Yesterday' },
    { id: 'doc-5', name: 'SRS', fullName: 'Software Requirements Specification', projectId: 'healthcare', icon: '📋', size: '1.1 MB', date: 'Yesterday' },
    { id: 'doc-6', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'edtech', icon: '📄', size: '980 KB', date: '2 days ago' },
    { id: 'doc-7', name: 'User Stories', fullName: 'User Story Document', projectId: 'fintech', icon: '📝', size: '320 KB', date: '3 days ago' },
  ],

  agents: [
    { id: 'ba', initials: 'BA', name: 'Business Analyst', role: 'Requirements Analysis & Elicitation', status: 'active', task: 'Analyzing E-Commerce requirements', cls: 'ba' },
    { id: 'pm', initials: 'PM', name: 'Product Manager', role: 'Backlog & Prioritization', status: 'active', task: 'Reviewing EdTech user stories', cls: 'pm' },
    { id: 'ux', initials: 'UX', name: 'UX Researcher', role: 'User Research & Prototyping', status: 'standby', task: null, cls: 'ux' },
    { id: 'sa', initials: 'SA', name: 'Solution Architect', role: 'Technical Architecture Design', status: 'standby', task: null, cls: 'sa' },
  ],

  activeProjectId: 'ecommerce',
  notifications: 2,
};

// ════════════════════════════ ICON HELPERS ════════════════════════════
const PROJECT_ICONS = {
  ecommerce: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>`,
  healthcare: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`,
  edtech:    `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>`,
  fintech:   `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`,
};

const ICON_STROKE_COLOR = {
  ecommerce: '#4f8cff',
  healthcare: '#22d3a5',
  edtech:    '#a855f7',
  fintech:   '#f59e0b',
};

// ════════════════════════════ VIEW SWITCHING ════════════════════════════
function switchView(viewId, navEl) {
  // Hide all views
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  // Remove active from all nav items
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  // Show target view
  const view = document.getElementById('view-' + viewId);
  if (view) view.classList.add('active');

  // Activate nav item
  if (navEl) navEl.classList.add('active');

  // Update page title
  const titles = {
    'dashboard':      'Dashboard',
    'projects':       'Projects',
    'active-project': 'Active Project',
    'user-stories':   'User Stories',
    'documents':      'Documents',
    'ai-agents':      'AI Agents',
    'settings':       'Settings',
  };
  document.getElementById('page-title').textContent = titles[viewId] || 'Dashboard';

  // Render dynamic views
  if (viewId === 'projects')       renderProjectsGrid();
  if (viewId === 'active-project') renderActiveProject();
  if (viewId === 'user-stories')   renderUserStories();
  if (viewId === 'documents')      renderDocuments();
  if (viewId === 'ai-agents')      renderAgentsGrid();
  if (viewId === 'settings')       renderSettings();

  // Close any open panels
  closeNotificationsPanel();
  closeUserMenu();

  return false;
}

// ════════════════════════════ PROJECTS GRID ════════════════════════════
function renderProjectsGrid() {
  const grid = document.getElementById('projects-grid');
  if (!grid) return;

  grid.innerHTML = store.projects.map(p => `
    <div class="project-grid-card" onclick="openProject('${p.id}')" tabindex="0" role="button" aria-label="Open ${p.name}"
         onkeydown="if(event.key==='Enter') openProject('${p.id}')">
      <div class="pgc-header">
        <div class="pgc-icon project-icon ${p.icon}">${iconSvg(p.icon)}</div>
        <span class="project-status ${p.status}">${capitalize(p.status)}</span>
      </div>
      <div class="pgc-name">${p.name}</div>
      <div class="pgc-desc">${p.desc}</div>
      <div class="project-progress-bar" role="progressbar" aria-valuenow="${p.progress}" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-fill ${p.status}" style="width:${p.progress}%"></div>
      </div>
      <div class="pgc-footer" style="margin-top:10px">
        <span class="pgc-progress"><span>${p.progress}%</span> complete</span>
        <span style="font-size:11px;color:var(--text-muted)">${p.updatedLabel}</span>
      </div>
    </div>
  `).join('');
}

function iconSvg(iconKey) {
  return (PROJECT_ICONS[iconKey] || '').replace('stroke="currentColor"', `stroke="${ICON_STROKE_COLOR[iconKey] || 'currentColor'}"`);
}

// ════════════════════════════ ACTIVE PROJECT ════════════════════════════
function renderActiveProject() {
  const el = document.getElementById('active-project-container');
  if (!el) return;
  const p = store.projects.find(x => x.id === store.activeProjectId) || store.projects[0];
  const projectStories = store.userStories.filter(s => s.projectId === p.id);
  const projectDocs = store.documents.filter(d => d.projectId === p.id);

  el.innerHTML = `
    <div class="apc-hero">
      <div class="apc-header">
        <div class="apc-icon project-icon ${p.icon}">${iconSvg(p.icon)}</div>
        <div>
          <div class="apc-title">${p.name}</div>
          <div class="apc-subtitle">${p.desc}</div>
        </div>
        <span class="project-status ${p.status}" style="margin-left:auto">${capitalize(p.status)}</span>
      </div>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-muted);margin-bottom:6px">
          <span>Overall progress</span><span style="color:var(--text-primary);font-weight:700">${p.progress}%</span>
        </div>
        <div class="project-progress-bar" style="height:8px" role="progressbar" aria-valuenow="${p.progress}" aria-valuemin="0" aria-valuemax="100">
          <div class="progress-fill ${p.status}" style="width:${p.progress}%"></div>
        </div>
      </div>
      <div class="apc-stats-row">
        <div class="apc-stat">
          <div class="apc-stat-label">User stories</div>
          <div class="apc-stat-value">${projectStories.length}</div>
        </div>
        <div class="apc-stat">
          <div class="apc-stat-label">Documents</div>
          <div class="apc-stat-value">${projectDocs.length}</div>
        </div>
        <div class="apc-stat">
          <div class="apc-stat-label">Last updated</div>
          <div class="apc-stat-value" style="font-size:14px">${p.updatedLabel}</div>
        </div>
      </div>
    </div>

    <div style="margin-bottom:14px;font-size:14px;font-weight:700;color:var(--text-primary)">User Stories</div>
    <div class="stories-container" style="margin-bottom:24px">
      ${projectStories.map(s => storyCardHTML(s)).join('') || '<p style="color:var(--text-muted);font-size:13px">No user stories yet. Generate with AI.</p>'}
    </div>

    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <div style="font-size:14px;font-weight:700;color:var(--text-primary)">Documents</div>
      <button class="btn-primary" onclick="exportDocument()" style="padding:6px 14px;font-size:12px">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Export
      </button>
    </div>
    <div class="docs-grid">
      ${projectDocs.map(d => docCardHTML(d)).join('') || '<p style="color:var(--text-muted);font-size:13px">No documents yet.</p>'}
    </div>

    <div style="margin-top:24px;display:flex;gap:10px">
      <button class="btn-primary" onclick="generateStories()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        Generate Stories with AI
      </button>
      <button class="btn-secondary" onclick="switchView('projects', document.getElementById('nav-projects'))">← All projects</button>
    </div>
  `;
}

// ════════════════════════════ USER STORIES ════════════════════════════
function storyCardHTML(s) {
  return `
    <div class="story-card">
      <div class="story-id">${s.id}</div>
      <div class="story-body">
        <div class="story-text">${s.text}</div>
        <div class="story-tags">${s.tags.map(t => `<span class="story-tag">${t}</span>`).join('')}</div>
      </div>
      <span class="story-priority ${s.priority}">${capitalize(s.priority)}</span>
    </div>
  `;
}

function renderUserStories() {
  const el = document.getElementById('stories-container');
  if (!el) return;
  el.innerHTML = store.userStories.map(s => storyCardHTML(s)).join('');
}

function generateStories() {
  showToast('info', '🤖 AI is generating new user stories…');
  setTimeout(() => {
    const newStory = {
      id: 'US-00' + (store.userStories.length + 1),
      projectId: store.activeProjectId,
      text: `As a <strong>user</strong>, I want to receive AI-powered suggestions so that I can improve my workflow.`,
      tags: ['AI', 'Suggestions', 'UX'],
      priority: 'medium',
    };
    store.userStories.push(newStory);
    // Update stat
    const statEl = document.querySelector('#stat-user-stories .stat-value');
    if (statEl) animateCount(statEl, parseInt(statEl.textContent), store.userStories.length);
    renderUserStories();
    showToast('success', '✅ New user story generated!');
  }, 1800);
}

// ════════════════════════════ DOCUMENTS ════════════════════════════
function docCardHTML(d) {
  const p = store.projects.find(x => x.id === d.projectId);
  return `
    <div class="doc-card" onclick="downloadDoc('${d.id}')">
      <div class="doc-icon">${d.icon}</div>
      <div class="doc-name">${d.name}</div>
      <div class="doc-proj">${p ? p.name : ''} · ${d.date}</div>
      <button class="doc-dl-btn" onclick="event.stopPropagation(); downloadDoc('${d.id}')">⬇ Download (${d.size})</button>
    </div>
  `;
}

function renderDocuments() {
  const el = document.getElementById('docs-grid');
  if (!el) return;
  el.innerHTML = store.documents.map(d => docCardHTML(d)).join('');
}

function downloadDoc(docId) {
  const doc = store.documents.find(d => d.id === docId);
  if (!doc) return;
  showToast('success', `⬇ Downloading ${doc.name}…`);
}

function downloadProject(projId) {
  const proj = store.projects.find(p => p.id === projId);
  if (!proj) return;
  showToast('success', `⬇ Preparing ${proj.name} documents for download…`);
}

function exportDocument() {
  showToast('info', '📤 Exporting document…');
  setTimeout(() => {
    const newDoc = {
      id: 'doc-' + (store.documents.length + 1),
      name: 'SRS',
      fullName: 'Software Requirements Specification',
      projectId: store.activeProjectId,
      icon: '📋',
      size: '1.2 MB',
      date: 'Just now',
    };
    store.documents.push(newDoc);
    const statEl = document.querySelector('#stat-docs .stat-value');
    if (statEl) animateCount(statEl, parseInt(statEl.textContent), store.documents.length);
    renderDocuments();
    showToast('success', '✅ Document exported successfully!');
  }, 1500);
}

// ════════════════════════════ AI AGENTS GRID ════════════════════════════
function renderAgentsGrid() {
  const el = document.getElementById('agents-grid-view');
  if (!el) return;
  el.innerHTML = store.agents.map(a => `
    <div class="agent-grid-card" tabindex="0" onclick="toggleAgentStatus('${a.id}')" onkeydown="if(event.key==='Enter') toggleAgentStatus('${a.id}')">
      <div class="agc-avatar agent-avatar ${a.cls}">${a.initials}</div>
      <div class="agc-name">${a.name}</div>
      <div class="agc-role">${a.role}</div>
      <span class="agc-status-badge ${a.status}">
        ${a.status === 'active' ? '<span class="live-dot" style="width:6px;height:6px"></span>' : ''}
        ${a.status === 'active' ? (a.task || 'Active') : 'Standby'}
      </span>
    </div>
  `).join('');
}

function toggleAgentStatus(agentId) {
  const agent = store.agents.find(a => a.id === agentId);
  if (!agent) return;
  if (agent.status === 'active') {
    agent.status = 'standby';
    agent.task = null;
    showToast('info', `${agent.name} set to Standby`);
  } else {
    agent.status = 'active';
    agent.task = 'Analyzing requirements';
    showToast('success', `${agent.name} is now Active`);
  }
  renderAgentsGrid();
  // Re-render agents on call if dashboard visible
  renderAgentsOnCall();
}

function renderAgentsOnCall() {
  const list = document.getElementById('agents-list');
  if (!list) return;
  list.innerHTML = store.agents.map(a => `
    <li class="agent-item ${a.status === 'active' ? 'active-agent' : ''}" role="listitem" tabindex="0"
        onclick="toggleAgentStatus('${a.id}')" onkeydown="if(event.key==='Enter') toggleAgentStatus('${a.id}')">
      <div class="agent-avatar ${a.cls}">${a.initials}</div>
      <div class="agent-info">
        <span class="agent-name">${a.name}</span>
        <span class="agent-status ${a.status}">${a.status === 'active' ? 'Active · ' + (a.task || 'Working') : 'Standby'}</span>
      </div>
      <div class="agent-indicator ${a.status}"></div>
    </li>
  `).join('');
}

// ════════════════════════════ SETTINGS ════════════════════════════
function renderSettings() {
  const el = document.getElementById('settings-container');
  if (!el) return;
  el.innerHTML = `
    <div class="settings-section">
      <div class="settings-section-title">Notifications</div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Email notifications</div>
          <div class="settings-row-desc">Receive project updates via email</div>
        </div>
        <label class="toggle"><input type="checkbox" checked onchange="showToast('info','Email notifications updated')"><span class="toggle-slider"></span></label>
      </div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">AI analysis alerts</div>
          <div class="settings-row-desc">Get notified when AI completes analysis</div>
        </div>
        <label class="toggle"><input type="checkbox" checked onchange="showToast('info','AI alerts updated')"><span class="toggle-slider"></span></label>
      </div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Weekly digest</div>
          <div class="settings-row-desc">Summary of weekly activity</div>
        </div>
        <label class="toggle"><input type="checkbox" onchange="showToast('info','Weekly digest updated')"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">AI Preferences</div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Auto-generate user stories</div>
          <div class="settings-row-desc">AI automatically generates stories on project creation</div>
        </div>
        <label class="toggle"><input type="checkbox" checked onchange="showToast('info','Auto-generate updated')"><span class="toggle-slider"></span></label>
      </div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Smart document suggestions</div>
          <div class="settings-row-desc">AI suggests relevant document templates</div>
        </div>
        <label class="toggle"><input type="checkbox" checked onchange="showToast('info','Smart suggestions updated')"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">Account</div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Arjun Kumar</div>
          <div class="settings-row-desc">arjun.kumar@company.com · Product Manager</div>
        </div>
        <button class="btn-secondary" onclick="showToast('info','Profile editing coming soon')" style="font-size:12px;padding:6px 14px">Edit profile</button>
      </div>
      <div class="settings-row">
        <div class="settings-row-info">
          <div class="settings-row-label">Two-factor authentication</div>
          <div class="settings-row-desc">Add an extra layer of security</div>
        </div>
        <label class="toggle"><input type="checkbox" onchange="showToast('info','2FA setting updated')"><span class="toggle-slider"></span></label>
      </div>
    </div>
  `;
}

// ════════════════════════════ PROJECT OPEN ════════════════════════════
function openProject(projId) {
  store.activeProjectId = projId;
  const proj = store.projects.find(p => p.id === projId);
  if (proj) showToast('info', `Opening ${proj.name}…`);
  switchView('active-project', document.getElementById('nav-active-project'));
}

// ════════════════════════════ NEW PROJECT MODAL ════════════════════════════
function openNewProjectModal() {
  const modal = document.getElementById('new-project-modal');
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  document.getElementById('proj-name').focus();
  document.addEventListener('keydown', handleModalKeydown);
}

function closeNewProjectModal() {
  const modal = document.getElementById('new-project-modal');
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  document.getElementById('new-project-form').reset();
  document.removeEventListener('keydown', handleModalKeydown);
}

function handleModalKeydown(e) {
  if (e.key === 'Escape') closeNewProjectModal();
}

function submitNewProject(e) {
  e.preventDefault();
  const name = document.getElementById('proj-name').value.trim();
  const desc = document.getElementById('proj-desc').value.trim();
  const type = document.getElementById('proj-type').value;

  if (!name) return;

  const iconMap = { web: 'ecommerce', mobile: 'fintech', api: 'healthcare', platform: 'edtech', other: 'edtech' };
  const newProject = {
    id: 'proj-' + Date.now(),
    name,
    desc: desc || 'New project',
    type,
    status: 'pending',
    progress: 0,
    icon: iconMap[type] || 'ecommerce',
    updatedLabel: 'Just now',
    stories: 0,
    docs: 0,
  };

  store.projects.unshift(newProject);
  closeNewProjectModal();

  // Update badge and stat
  updateProjectBadge();
  const statEl = document.querySelector('#stat-total-projects .stat-value');
  if (statEl) animateCount(statEl, parseInt(statEl.textContent), store.projects.length);

  showToast('success', `🚀 "${name}" created! AI is analyzing…`);

  // Simulate AI analysis
  setTimeout(() => {
    newProject.status = 'analyzed';
    newProject.progress = Math.floor(Math.random() * 30) + 20;
    newProject.updatedLabel = 'Just now';
    showToast('info', `🤖 AI completed initial analysis for "${name}"`);
    if (document.getElementById('view-projects').classList.contains('active')) renderProjectsGrid();
  }, 3000);
}

function updateProjectBadge() {
  const badge = document.querySelector('#nav-projects .nav-badge');
  if (badge) badge.textContent = store.projects.length;
}

// Click outside modal closes it
document.getElementById('new-project-modal').addEventListener('click', function(e) {
  if (e.target === this) closeNewProjectModal();
});

// ════════════════════════════ REFRESH ════════════════════════════
function handleRefresh() {
  const btn = document.getElementById('refresh-btn');
  btn.classList.add('spin');
  showToast('info', '🔄 Refreshing dashboard…');
  setTimeout(() => {
    btn.classList.remove('spin');
    showToast('success', '✅ Dashboard refreshed!');
  }, 1200);
}

// ════════════════════════════ NOTIFICATIONS ════════════════════════════
function toggleNotifications() {
  const panel = document.getElementById('notifications-panel');
  const isOpen = panel.classList.contains('open');
  if (isOpen) {
    closeNotificationsPanel();
  } else {
    panel.classList.add('open');
    panel.setAttribute('aria-hidden', 'false');
    // Close user dropdown
    closeUserMenu();
  }
}

function closeNotificationsPanel() {
  const panel = document.getElementById('notifications-panel');
  panel.classList.remove('open');
  panel.setAttribute('aria-hidden', 'true');
}

function clearNotifications() {
  store.notifications = 0;
  const dot = document.querySelector('.notif-dot');
  if (dot) dot.style.display = 'none';
  document.querySelectorAll('.notif-item.unread').forEach(el => {
    el.classList.remove('unread');
    el.querySelector('.notif-dot-sm')?.classList.add('read');
  });
  showToast('success', '✅ All notifications marked as read');
}

// ════════════════════════════ USER MENU ════════════════════════════
function toggleUserMenu() {
  const dd = document.getElementById('user-dropdown');
  const isOpen = dd.classList.contains('open');
  const btn = document.getElementById('user-profile-btn');
  if (isOpen) {
    closeUserMenu();
  } else {
    dd.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
    closeNotificationsPanel();
  }
}

function closeUserMenu() {
  const dd = document.getElementById('user-dropdown');
  dd.classList.remove('open');
  document.getElementById('user-profile-btn').setAttribute('aria-expanded', 'false');
}

// ════════════════════════════ SEARCH ════════════════════════════
let searchTimeout = null;
function handleSearch(query) {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    const q = query.toLowerCase().trim();
    if (!q) {
      // Restore all project cards
      document.querySelectorAll('.project-card').forEach(c => c.style.display = '');
      return;
    }
    // Filter project cards in dashboard
    document.querySelectorAll('.project-card').forEach(card => {
      const name = card.querySelector('.project-name')?.textContent.toLowerCase() || '';
      const desc = card.querySelector('.project-desc')?.textContent.toLowerCase() || '';
      card.style.display = (name.includes(q) || desc.includes(q)) ? '' : 'none';
    });
    // Filter project grid cards
    document.querySelectorAll('.project-grid-card').forEach(card => {
      const name = card.querySelector('.pgc-name')?.textContent.toLowerCase() || '';
      const desc = card.querySelector('.pgc-desc')?.textContent.toLowerCase() || '';
      card.style.display = (name.includes(q) || desc.includes(q)) ? '' : 'none';
    });
  }, 200);
}

// ════════════════════════════ TOAST ════════════════════════════
function showToast(type, message) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    success: `<svg class="toast-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    error:   `<svg class="toast-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    info:    `<svg class="toast-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  };

  toast.innerHTML = (icons[type] || '') + `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastIn 200ms reverse forwards';
    setTimeout(() => toast.remove(), 200);
  }, 3500);
}

// ════════════════════════════ COUNT ANIMATION ════════════════════════════
function animateCount(el, from, to) {
  const duration = 800;
  const start = performance.now();
  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(from + (to - from) * eased);
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

// ════════════════════════════ HELPERS ════════════════════════════
function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

// Close panels on outside click
document.addEventListener('click', function(e) {
  const notifPanel = document.getElementById('notifications-panel');
  const notifBtn   = document.getElementById('notifications-btn');
  const userMenu   = document.getElementById('user-dropdown');
  const userBtn    = document.getElementById('user-profile-btn');

  if (!notifPanel.contains(e.target) && !notifBtn.contains(e.target)) {
    closeNotificationsPanel();
  }
  if (!userMenu.contains(e.target) && !userBtn.contains(e.target)) {
    closeUserMenu();
  }
});

// ════════════════════════════ PROGRESS BAR ANIMATION ON LOAD ════════════════════════════
function animateProgressBars() {
  document.querySelectorAll('.progress-fill').forEach(bar => {
    const targetWidth = bar.style.width;
    bar.style.width = '0%';
    requestAnimationFrame(() => {
      bar.style.transition = 'width 1.2s cubic-bezier(0.4,0,0.2,1)';
      bar.style.width = targetWidth;
    });
  });
}

// ════════════════════════════ KEYBOARD SHORTCUT ════════════════════════════
document.addEventListener('keydown', function(e) {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    document.getElementById('global-search').focus();
  }
});

// ════════════════════════════ INIT ════════════════════════════
document.addEventListener('DOMContentLoaded', function () {
  // Animate stat counters
  document.querySelectorAll('.stat-value[data-target]').forEach(el => {
    const target = parseInt(el.getAttribute('data-target'));
    animateCount(el, 0, target);
  });

  // Animate progress bars
  setTimeout(animateProgressBars, 300);

  // Set dashboard as default active view
  switchView('dashboard', document.getElementById('nav-dashboard'));
});
