import React from 'react';

const NotificationsPanel = ({
  isOpen,
  notificationsList,
  onClearAll
}) => {
  return (
    <div
      className={`notifications-panel ${isOpen ? 'open' : ''}`}
      id="notifications-panel"
      role="dialog"
      aria-label="Notifications"
      aria-hidden={isOpen ? "false" : "true"}
    >
      <div className="notif-header">
        <span>Notifications</span>
        <button className="notif-clear" onClick={onClearAll}>Mark all read</button>
      </div>
      <ul className="notif-list" role="list">
        {notificationsList.map((notif) => (
          <li key={notif.id} className={`notif-item ${notif.unread ? 'unread' : ''}`}>
            <div className={`notif-dot-sm ${notif.unread ? '' : 'read'}`}></div>
            <div className="notif-content">
              <p dangerouslySetInnerHTML={{ __html: notif.text }}></p>
              <span className="notif-time">{notif.time}</span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NotificationsPanel;
