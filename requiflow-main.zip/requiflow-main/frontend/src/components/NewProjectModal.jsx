import React, { useState, useEffect, useRef } from 'react';

const NewProjectModal = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [type, setType] = useState('web');
  const [priority, setPriority] = useState('medium');
  const [file, setFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const nameInputRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setName('');
      setDesc('');
      setType('web');
      setPriority('medium');
      setFile(null);
      setIsDragging(false);
      // Focus the name field when opening
      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  };

  const validateAndSetFile = (selectedFile) => {
    const validExtensions = ['pdf', 'doc', 'docx'];
    const fileExt = selectedFile.name.split('.').pop().toLowerCase();
    if (validExtensions.includes(fileExt)) {
      setFile(selectedFile);
    } else {
      alert('Please upload a valid file format (.pdf, .doc, .docx)');
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({ name: name.trim(), desc: desc.trim(), type, priority, file });
  };

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div
      className="modal-overlay open"
      id="new-project-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      aria-hidden="false"
      onClick={handleOverlayClick}
    >
      <div className="modal" id="new-project-modal-box">
        <div className="modal-header">
          <h2 className="modal-title" id="modal-title">Create New Project</h2>
          <button className="modal-close" onClick={onClose} aria-label="Close modal">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        <form className="modal-form" id="new-project-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="proj-name">Project name *</label>
            <input
              ref={nameInputRef}
              type="text"
              className="form-input"
              id="proj-name"
              placeholder="e.g. Mobile Banking App"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="proj-desc">Description</label>
            <textarea
              className="form-input form-textarea"
              id="proj-desc"
              placeholder="Briefly describe the project goals and scope…"
              rows={2}
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            ></textarea>
          </div>

          {/* File Upload Section */}
          <div className="form-group">
            <label className="form-label">Upload Requirements Document (PDF, DOC, DOCX)</label>
            <input
              type="file"
              ref={fileInputRef}
              accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              onChange={handleFileChange}
              style={{ display: 'none' }}
              id="proj-file-input"
            />
            
            {!file ? (
              <div
                className={`file-drop-zone ${isDragging ? 'dragging' : ''}`}
                onClick={() => fileInputRef.current?.click()}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <div className="drop-zone-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="17 8 12 3 7 8"></polyline>
                    <line x1="12" y1="3" x2="12" y2="15"></line>
                  </svg>
                </div>
                <div className="drop-zone-text">
                  <span>Click to upload</span> or drag and drop
                </div>
                <div className="drop-zone-subtext">
                  Supports PDF, DOC, DOCX (up to 25MB)
                </div>
              </div>
            ) : (
              <div className="file-attached-box">
                <div className="file-icon-badge">
                  {file.name.endsWith('.pdf') ? '📄 PDF' : '📝 DOC'}
                </div>
                <div className="file-details">
                  <span className="file-name">{file.name}</span>
                  <span className="file-size">{formatFileSize(file.size)}</span>
                </div>
                <button
                  type="button"
                  className="file-remove-btn"
                  onClick={() => setFile(null)}
                  title="Remove file"
                  aria-label="Remove attached file"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
              </div>
            )}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            <div className="form-group">
              <label className="form-label" htmlFor="proj-type">Project type</label>
              <select
                className="form-input form-select"
                id="proj-type"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="web">Web Application</option>
                <option value="mobile">Mobile Application</option>
                <option value="api">API / Backend</option>
                <option value="platform">Platform</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="proj-priority">Priority</label>
              <select
                className="form-input form-select"
                id="proj-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
              </svg>
              Create & Analyze with AI
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewProjectModal;
