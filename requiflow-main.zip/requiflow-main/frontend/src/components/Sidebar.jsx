import React from 'react';

const Sidebar = ({
  currentView,
  onViewChange,
  projectsCount,
  userMenuOpen,
  setUserMenuOpen,
  closeNotifications
}) => {
  const toggleUserMenu = (e) => {
    e.stopPropagation();
    setUserMenuOpen(!userMenuOpen);
    closeNotifications();
  };

  const handleNavClick = (viewId, e) => {
    e.preventDefault();
    onViewChange(viewId);
  };

  return (
    <aside className="sidebar" id="sidebar" role="navigation" aria-label="Main navigation">
      {/* Logo */}
      <div className="sidebar-logo">
        <img src="/logo.png" alt="RequiFlow" className="brand-logo-img" />
      </div>

      {/* Nav sections */}
      <nav className="sidebar-nav">
        <div className="nav-section">
          <span className="nav-section-label">Overview</span>
          <ul className="nav-list" role="list">
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'dashboard' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('dashboard', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="7" height="7"></rect>
                    <rect x="14" y="3" width="7" height="7"></rect>
                    <rect x="14" y="14" width="7" height="7"></rect>
                    <rect x="3" y="14" width="7" height="7"></rect>
                  </svg>
                </span>
                Dashboard
              </a>
            </li>
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'projects' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('projects', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                  </svg>
                </span>
                Projects
                <span className="nav-badge">{projectsCount}</span>
              </a>
            </li>
          </ul>
        </div>

        <div className="nav-section">
          <span className="nav-section-label">Workspace</span>
          <ul className="nav-list" role="list">
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'active-project' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('active-project', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                  </svg>
                </span>
                Active project
              </a>
            </li>
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'user-stories' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('user-stories', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                  </svg>
                </span>
                User stories
              </a>
            </li>
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'documents' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('documents', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                    <polyline points="13 2 13 9 20 9"></polyline>
                  </svg>
                </span>
                Documents
              </a>
            </li>
          </ul>
        </div>

        <div className="nav-section">
          <span className="nav-section-label">Agents</span>
          <ul className="nav-list" role="list">
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'ai-agents' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('ai-agents', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                  </svg>
                </span>
                AI agents
              </a>
            </li>
            <li>
              <a
                href="#"
                className={`nav-item ${currentView === 'settings' ? 'active' : ''}`}
                onClick={(e) => handleNavClick('settings', e)}
              >
                <span className="nav-icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                  </svg>
                </span>
                Settings
              </a>
            </li>
          </ul>
        </div>
      </nav>

      {/* User profile */}
      <div className="sidebar-footer">
        <div
          className="user-profile"
          id="user-profile-btn"
          onClick={toggleUserMenu}
          role="button"
          tabIndex={0}
          aria-label="User menu"
          aria-expanded={userMenuOpen ? "true" : "false"}
        >
          <div className="user-avatar">HM</div>
          <div className="user-info">
            <span className="user-name">Hannah Mariam</span>
            <span className="user-role">Product Manager</span>
          </div>
          <button className="user-menu-btn" aria-label="More options">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="5" r="1"></circle>
              <circle cx="12" cy="12" r="1"></circle>
              <circle cx="12" cy="19" r="1"></circle>
            </svg>
          </button>
        </div>
        <div className={`user-dropdown ${userMenuOpen ? 'open' : ''}`} id="user-dropdown" role="menu" aria-hidden={userMenuOpen ? "false" : "true"}>
          <button className="dropdown-item" role="menuitem" onClick={() => onViewChange('settings')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            Profile
          </button>
          <button className="dropdown-item" role="menuitem" onClick={() => onViewChange('settings')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="3"></circle>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
            </svg>
            Settings
          </button>
          <div className="dropdown-divider"></div>
          <button className="dropdown-item danger" role="menuitem" onClick={() => alert('Signing out...')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Sign out
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
