import React, { useState, useEffect, useRef } from 'react';

const AnimatedCounter = ({ value, duration = 800 }) => {
  const [count, setCount] = useState(0);
  const prevValueRef = useRef(0);

  useEffect(() => {
    let start = null;
    const from = prevValueRef.current;
    const to = value;

    if (from === to) {
      setCount(to);
      return;
    }

    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // cubic ease out
      const current = Math.round(from + (to - from) * eased);
      setCount(current);

      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        prevValueRef.current = to;
      }
    };

    const animId = window.requestAnimationFrame(step);
    return () => window.cancelAnimationFrame(animId);
  }, [value, duration]);

  return <>{count}</>;
};

export default AnimatedCounter;
