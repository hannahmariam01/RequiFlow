import React, { useState, useEffect, useRef } from 'react';

const Topbar = ({
  pageTitle,
  searchVal,
  onSearchChange,
  onRefresh,
  notificationsCount,
  onNotificationsToggle,
  onNewProjectClick
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const searchInputRef = useRef(null);

  const handleRefreshClick = () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    onRefresh();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1200);
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="topbar" role="banner">
      <div className="topbar-left">
        <h1 className="page-title" id="page-title">{pageTitle}</h1>
      </div>
      <div className="topbar-right">
        <div className="search-wrapper" role="search">
          <span className="search-icon" aria-hidden="true">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </span>
          <input
            ref={searchInputRef}
            type="search"
            className="search-input"
            id="global-search"
            placeholder="Search projects…"
            aria-label="Search projects"
            value={searchVal}
            onChange={(e) => onSearchChange(e.target.value)}
          />
          <span className="search-kbd">⌘K</span>
        </div>
        <button
          className={`icon-btn ${isRefreshing ? 'spin' : ''}`}
          id="refresh-btn"
          onClick={handleRefreshClick}
          title="Refresh"
          aria-label="Refresh dashboard"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <polyline points="1 20 1 14 7 14"></polyline>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
          </svg>
        </button>
        <button
          className="icon-btn notification-btn"
          id="notifications-btn"
          onClick={onNotificationsToggle}
          title="Notifications"
          aria-label="Notifications"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          {notificationsCount > 0 && (
            <span className="notif-dot" aria-label={`${notificationsCount} unread notifications`}>
              {notificationsCount}
            </span>
          )}
        </button>
        <button className="btn-primary" id="new-project-btn" onClick={onNewProjectClick} aria-label="Create new project">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
          New project
        </button>
      </div>
    </header>
  );
};

export default Topbar;
