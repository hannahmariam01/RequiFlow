import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './AuthView.css';

const VerifyEmailView = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState('verifying'); // 'verifying', 'success', 'error'
  const [message, setMessage] = useState('Verifying your email address...');

  useEffect(() => {
    const verifyToken = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/auth/verify/${token}`);
        const data = await response.json();

        if (response.ok) {
          setStatus('success');
          setMessage('Email successfully verified! You can now sign in.');
          setTimeout(() => {
            navigate('/auth');
          }, 3000);
        } else {
          setStatus('error');
          setMessage(data.message || 'Verification failed. The link may have expired.');
        }
      } catch (err) {
        setStatus('error');
        setMessage('A network error occurred. Please try again.');
      }
    };

    if (token) {
      verifyToken();
    }
  }, [token, navigate]);

  return (
    <div className="auth-root">
      <div className="auth-container">
        <div className="auth-brand">
          <img src="/logo.png" alt="RequiFlow" className="auth-logo" />
          <h1>RequiFlow</h1>
        </div>

        <div className="auth-card" style={{ textAlign: 'center', padding: '50px 32px' }}>
          {status === 'verifying' && (
            <>
              <div className="lp-acc-spinner" style={{ margin: '0 auto 20px', width: 24, height: 24 }} />
              <h2 style={{ fontSize: 18, marginBottom: 10 }}>{message}</h2>
              <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13 }}>Please wait while we validate your secure token.</p>
            </>
          )}

          {status === 'success' && (
            <>
              <div style={{ color: '#3ecf8e', fontSize: 40, marginBottom: 10 }}>✓</div>
              <h2 style={{ fontSize: 18, marginBottom: 10 }}>{message}</h2>
              <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13 }}>Redirecting to Sign In...</p>
            </>
          )}

          {status === 'error' && (
            <>
              <div style={{ color: '#ff6b6b', fontSize: 40, marginBottom: 10 }}>✕</div>
              <h2 style={{ fontSize: 18, marginBottom: 10 }}>{message}</h2>
              <button className="auth-submit-btn" onClick={() => navigate('/auth')}>
                Back to Sign In
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerifyEmailView;
