import React from 'react';

const DocumentsView = ({
  documents,
  projects,
  onExportDocument,
  onDownloadDocument
}) => {
  return (
    <section className="view active" id="view-documents" aria-label="Documents view">
      <div className="view-header">
        <h2 className="view-heading">Documents</h2>
        <button className="btn-primary" onClick={onExportDocument}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
          </svg>
          Export
        </button>
      </div>
      <div className="docs-grid" id="docs-grid">
        {documents.map((d) => {
          const p = projects.find(x => x.id === d.projectId);
          return (
            <div key={d.id} className="doc-card" onClick={() => onDownloadDocument(d.id)}>
              <div className="doc-icon">{d.icon}</div>
              <div className="doc-name">{d.name}</div>
              <div className="doc-proj">
                {p ? p.name : 'Unknown Project'} · {d.date}
              </div>
              <button
                className="doc-dl-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onDownloadDocument(d.id);
                }}
              >
                ⬇ Download ({d.size})
              </button>
            </div>
          );
        })}
        {documents.length === 0 && (
          <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: 'var(--text-muted)', padding: '40px 0' }}>
            No documents exported yet.
          </p>
        )}
      </div>
    </section>
  );
};

export default DocumentsView;
