import React, { useState, useEffect } from 'react';
import ProjectIcon from '../components/ProjectIcon';

const MermaidRenderer = ({ chart }) => {
  const [svg, setSvg] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!chart || !window.mermaid) return;

    const renderChart = async () => {
      try {
        setError(null);
        window.mermaid.initialize({
          startOnLoad: false,
          theme: 'dark',
          securityLevel: 'loose',
          themeVariables: {
            background: '#0c1120',
            primaryColor: '#0f162a',
            primaryTextColor: '#e8edf8',
            lineColor: '#4f8cff',
            secondaryColor: '#1e293b',
            tertiaryColor: '#0f172a'
          }
        });
        
        // Defensive regex replacement to correct LLM-generated arrow-label syntax errors
        const sanitizedChart = chart
          .replace(/-->\|([^|]+)\|>/g, '-->|$1|')
          .replace(/-->\|([^|]+)\|/g, (match, label) => {
            const cleanLabel = label.replace(/[()\[\]{}"'\/]/g, '');
            return `-->|${cleanLabel}|`;
          });
        
        const id = 'mermaid-' + Math.floor(Math.random() * 100000);
        const { svg: renderedSvg } = await window.mermaid.render(id, sanitizedChart);
        setSvg(renderedSvg);
      } catch (err) {
        console.error('Mermaid render error:', err);
        setError('Flowchart visualization could not be rendered due to formatting constraints.');
      }
    };

    renderChart();
  }, [chart]);

  if (error) {
    return (
      <div style={{
        padding: '16px',
        border: '1px solid var(--accent-red)',
        borderRadius: '10px',
        color: 'var(--accent-red)',
        background: 'rgba(244, 63, 94, 0.05)',
        fontSize: '13px'
      }}>
        <div>⚠️ {error}</div>
        <pre style={{
          marginTop: '12px',
          fontFamily: 'monospace',
          fontSize: '11px',
          whiteSpace: 'pre-wrap',
          background: 'rgba(0,0,0,0.3)',
          padding: '10px',
          borderRadius: '6px'
        }}>{chart}</pre>
      </div>
    );
  }

  if (!svg) {
    return <div style={{ color: 'var(--text-secondary)', padding: '16px' }}>Initializing visual flowchart rendering...</div>;
  }

  return (
    <div 
      className="mermaid-svg-container" 
      dangerouslySetInnerHTML={{ __html: svg }} 
      style={{
        display: 'flex',
        justifyContent: 'center',
        background: 'rgba(12, 17, 32, 0.4)',
        padding: '24px',
        borderRadius: '14px',
        border: '1px solid var(--border-dim)',
        overflowX: 'auto',
        boxShadow: 'var(--shadow-card)'
      }}
    />
  );
};

const ActiveProjectView = ({
  projects,
  activeProjectId,
  userStories,
  documents,
  onGenerateStories,
  onExportDocument,
  onDownloadDocument,
  onViewChange,
  onClarificationSubmit
}) => {
  const p = projects.find(x => x.id === activeProjectId) || projects[0];
  const [activeTab, setActiveTab] = useState('stories'); // stories | requirements | architecture | tasks | flowchart
  const [answers, setAnswers] = useState({});

  // Reset tab when active project changes
  useEffect(() => {
    setActiveTab('stories');
    setAnswers({});
  }, [activeProjectId]);

  if (!p) {
    return (
      <section className="view active" id="view-active-project" aria-label="Active project view">
        <div className="view-header">
          <h2 className="view-heading">Active Project</h2>
        </div>
        <p style={{ color: 'var(--text-muted)' }}>No active project. Please select or create a project first.</p>
      </section>
    );
  }

  const projectStories = userStories.filter(s => s.projectId === p.id);
  const projectDocs = documents.filter(d => d.projectId === p.id);

  const handleSubmitAnswers = () => {
    if (onClarificationSubmit) {
      onClarificationSubmit(p.id, answers);
    }
  };

  // --- RENDER LOADING STATE ---
  if (p.status === 'analyzing') {
    return (
      <section className="view active" id="view-active-project" aria-label="Active project view">
        <div className="view-header">
          <h2 className="view-heading">Active Project: {p.name}</h2>
        </div>
        <div className="active-project-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px', minHeight: '400px' }}>
          <div style={{
            width: '50px',
            height: '50px',
            border: '4px solid var(--border-dim)',
            borderTopColor: 'var(--accent-blue)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            marginBottom: '24px'
          }} />
          <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '8px' }}>
            AI Agent Pipeline Processing...
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '13.5px', textAlign: 'center', maxWidth: '450px', lineHeight: 1.6 }}>
            The AI requirements engineers, solution architects, and project managers are collaborating to design specifications, break down tasks, and build your system's architecture flowchart.
          </p>
        </div>
      </section>
    );
  }

  // --- RENDER CLARIFICATION STATE ---
  if (p.status === 'clarifying' && p.questions && p.questions.length > 0) {
    return (
      <section className="view active" id="view-active-project" aria-label="Active project view">
        <div className="view-header">
          <h2 className="view-heading">Active Project: {p.name}</h2>
        </div>
        <div className="active-project-container" style={{ padding: '24px' }}>
          <div style={{ marginBottom: '24px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '16px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--accent-orange)', marginBottom: '6px' }}>
              🔍 AI Clarification Questionnaire
            </h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '13px', lineHeight: 1.5 }}>
              To construct a highly accurate tech stack and task list, the agents need details on the following incomplete areas.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px', marginBottom: '24px' }}>
            {p.questions.map((q) => (
              <div key={q.id} style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', borderRadius: '10px', padding: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>Question {q.id}</span>
                  <span style={{ fontSize: '11px', textTransform: 'uppercase', color: 'var(--accent-blue)', fontWeight: 600 }}>{q.category}</span>
                </div>
                <div style={{ fontSize: '13.5px', color: 'var(--text-secondary)', marginBottom: '12px', lineHeight: 1.5 }}>{q.question}</div>
                <input
                  type="text"
                  value={answers[q.id] || ''}
                  onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                  placeholder="Provide clarification details..."
                  style={{
                    width: '100%',
                    background: 'rgba(0,0,0,0.25)',
                    border: '1px solid var(--border-bright)',
                    borderRadius: '6px',
                    color: 'var(--text-primary)',
                    padding: '10px 14px',
                    fontSize: '13px',
                    outline: 'none'
                  }}
                />
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="btn-primary" onClick={handleSubmitAnswers}>
              Submit Answers & Continue Analysis
            </button>
            <button className="btn-secondary" onClick={() => onViewChange('projects')}>
              ← Back to Projects
            </button>
          </div>
        </div>
      </section>
    );
  }

  // --- RENDER MAIN ANALYZED PROJECT VIEW ---
  return (
    <section className="view active" id="view-active-project" aria-label="Active project view">
      <div className="view-header">
        <h2 className="view-heading">Active Project</h2>
      </div>

      <div className="active-project-container" id="active-project-container">
        {/* Project Hero Banner */}
        <div className="apc-hero">
          <div className="apc-header">
            <div className={`apc-icon project-icon ${p.icon}`}>
              <ProjectIcon name={p.icon} />
            </div>
            <div>
              <div className="apc-title">{p.name}</div>
              <div className="apc-subtitle">{p.desc}</div>
            </div>
            <span className={`project-status ${p.status}`} style={{ marginLeft: 'auto' }}>
              {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
            </span>
          </div>

          <div style={{ marginBottom: '14px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px' }}>
              <span>AI Integration Progress</span>
              <span style={{ color: 'var(--text-primary)', fontWeight: 700 }}>{p.progress}%</span>
            </div>
            <div className="project-progress-bar" style={{ height: '8px' }} role="progressbar" aria-valuenow={p.progress} aria-valuemin="0" aria-valuemax="100">
              <div className={`progress-fill ${p.status}`} style={{ width: `${p.progress}%` }}></div>
            </div>
          </div>

          <div className="apc-stats-row">
            <div className="apc-stat">
              <div className="apc-stat-label">User stories</div>
              <div className="apc-stat-value">{projectStories.length + (p.tasks ? p.tasks.length : 0)}</div>
            </div>
            <div className="apc-stat">
              <div className="apc-stat-label">Documents</div>
              <div className="apc-stat-value">{projectDocs.length + (p.architecture ? 1 : 0)}</div>
            </div>
            <div className="apc-stat">
              <div className="apc-stat-label">Last updated</div>
              <div className="apc-stat-value" style={{ fontSize: '14px' }}>{p.updatedLabel}</div>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        {p.architecture && (
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
            {[
              { id: 'stories', label: 'User Stories' },
              { id: 'requirements', label: 'AI Requirements Spec' },
              { id: 'architecture', label: 'Tech Architecture' },
              { id: 'tasks', label: 'Developer Checklist' },
              { id: 'flowchart', label: 'System Flowchart' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: '8px 16px',
                  fontSize: '13px',
                  fontWeight: 600,
                  borderRadius: '8px',
                  border: '1px solid',
                  borderColor: activeTab === tab.id ? 'var(--border-accent)' : 'transparent',
                  background: activeTab === tab.id ? 'rgba(79, 140, 255, 0.1)' : 'transparent',
                  color: activeTab === tab.id ? 'var(--text-accent)' : 'var(--text-secondary)',
                  cursor: 'pointer',
                  outline: 'none',
                  transition: 'var(--transition)'
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        )}

        {/* Tab Panels */}
        <div style={{ minHeight: '300px' }}>
          {activeTab === 'stories' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>User Stories</div>
                <button className="btn-primary" onClick={onExportDocument} style={{ padding: '6px 14px', fontSize: '12px' }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                  </svg>
                  Export
                </button>
              </div>
              <div className="stories-container" style={{ marginBottom: '24px' }}>
                {projectStories.map((s) => (
                  <div key={s.id} className="story-card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ display: 'flex', width: '100%', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                        <div className="story-id">{s.id}</div>
                        <div className="story-body">
                          <div className="story-text" dangerouslySetInnerHTML={{ __html: s.text }}></div>
                          <div className="story-tags">
                            {s.epic && (
                              <span className="story-tag" style={{ background: 'rgba(79, 140, 255, 0.12)', color: 'var(--accent-blue)', borderColor: 'rgba(79, 140, 255, 0.25)' }}>
                                📁 {s.epic}
                              </span>
                            )}
                            {s.tags.map((t, idx) => (
                              <span key={idx} className="story-tag">{t}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px', flexShrink: 0 }}>
                        <span className={`story-priority ${s.priority}`}>
                          {s.priority.charAt(0).toUpperCase() + s.priority.slice(1)}
                        </span>
                        {s.story_points && (
                          <span style={{
                            fontSize: '10.5px',
                            fontWeight: 700,
                            background: 'rgba(34, 211, 165, 0.1)',
                            color: 'var(--accent-green)',
                            border: '1px solid rgba(34, 211, 165, 0.2)',
                            padding: '2px 8px',
                            borderRadius: '12px',
                            fontFamily: 'monospace'
                          }}>
                            ⚡ {s.story_points} SP
                          </span>
                        )}
                      </div>
                    </div>

                    {s.acceptance_criteria && s.acceptance_criteria.length > 0 && (
                      <div style={{
                        marginTop: '8px',
                        padding: '12px 16px',
                        background: 'rgba(255, 255, 255, 0.02)',
                        border: '1px solid var(--border-dim)',
                        borderRadius: '8px'
                      }}>
                        <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>
                          Acceptance Criteria:
                        </div>
                        <ul style={{ listStyleType: 'none', paddingLeft: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '5px' }}>
                          {s.acceptance_criteria.map((ac, idx) => (
                            <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '12.5px', color: 'var(--text-secondary)' }}>
                              <span style={{ color: 'var(--accent-green)', fontWeight: 'bold', marginTop: '2px', fontSize: '11px' }}>✓</span>
                              <span>{ac}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
                {projectStories.length === 0 && (
                  <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>No custom stories yet. Click below to trigger additional AI stories.</p>
                )}
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>Documents</div>
              </div>
              <div className="docs-grid">
                {projectDocs.map((d) => (
                  <div key={d.id} className="doc-card" onClick={() => onDownloadDocument(d.id)}>
                    <div className="doc-icon">{d.icon}</div>
                    <div className="doc-name">{d.name}</div>
                    <div className="doc-proj">{p.name} · {d.date}</div>
                    <button
                      className="doc-dl-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDownloadDocument(d.id);
                      }}
                    >
                      ⬇ Download ({d.size})
                    </button>
                  </div>
                ))}
                {projectStories.length > 0 && (
                  <div className="doc-card" onClick={() => onExportDocument(p.id)}>
                    <div className="doc-icon">📄</div>
                    <div className="doc-name">User Stories PDF</div>
                    <div className="doc-proj">{p.name} · AI Generated</div>
                    <button
                      className="doc-dl-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        onExportDocument(p.id);
                      }}
                    >
                      ⬇ Download (PDF)
                    </button>
                  </div>
                )}
                {p.architecture && (
                  <div className="doc-card" onClick={() => onDownloadDocument('ai-architecture')}>
                    <div className="doc-icon">📋</div>
                    <div className="doc-name">AI System Architecture Package</div>
                    <div className="doc-proj">{p.name} · Generated</div>
                    <button className="doc-dl-btn" onClick={(e) => { e.stopPropagation(); alert('Preparing system architecture package for download...'); }}>
                      ⬇ Download
                    </button>
                  </div>
                )}
                {projectDocs.length === 0 && !p.architecture && projectStories.length === 0 && (
                  <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>No documents yet.</p>
                )}
              </div>

              <div style={{ marginTop: '24px', display: 'flex', gap: '10px' }}>
                <button className="btn-primary" onClick={onGenerateStories} style={{ background: 'linear-gradient(135deg, var(--accent-blue), #6366f1)', border: 'none' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '6px' }}>
                    <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m0-12.728l.707.707m11.314 11.314l.707.707M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10z"/>
                  </svg>
                  Generate User Stories with AI
                </button>
                <button className="btn-secondary" onClick={() => onViewChange('projects')}>
                  ← All projects
                </button>
              </div>
            </div>
          )}

          {activeTab === 'requirements' && p.requirements && (
            <div style={{ background: 'rgba(5, 8, 17, 0.2)', border: '1px solid var(--border-dim)', padding: '24px', borderRadius: '14px' }}>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                Requirements Specification
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Project Goal</div>
                  <div style={{ fontSize: '14px', color: 'var(--text-primary)', lineHeight: 1.6 }}>{p.requirements.project_goal}</div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>User Roles</div>
                    <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                      {p.requirements.user_types.map((u, i) => <li key={i} style={{ marginBottom: '4px' }}>{u}</li>)}
                    </ul>
                  </div>
                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Constraints</div>
                    <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                      {p.requirements.constraints.map((c, i) => <li key={i} style={{ marginBottom: '4px' }}>{c}</li>)}
                    </ul>
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Key Functional Features</div>
                  <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                    {p.requirements.features.map((f, i) => <li key={i} style={{ marginBottom: '4px' }}>{f}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'architecture' && p.architecture && (
            <div style={{ background: 'rgba(5, 8, 17, 0.2)', border: '1px solid var(--border-dim)', padding: '24px', borderRadius: '14px' }}>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                Technical Architecture Design
              </h4>
              
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '24px' }}>
                {[
                  { title: 'Frontend Stack', val: p.architecture.frontend, color: 'var(--accent-blue)' },
                  { title: 'Backend Runtime', val: p.architecture.backend, color: 'var(--accent-cyan)' },
                  { title: 'Database Configuration', val: p.architecture.database, color: 'var(--accent-purple)' }
                ].map((box, i) => (
                  <div key={i} style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', padding: '16px', borderRadius: '10px' }}>
                    <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>{box.title}</div>
                    <div style={{ fontSize: '13.5px', color: box.color, fontWeight: 600 }}>{box.val}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>Integrations & Services</div>
                  <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                    {p.architecture.services.map((s, i) => <li key={i} style={{ marginBottom: '4px' }}>{s}</li>)}
                  </ul>
                </div>
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>API Interfaces</div>
                  <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                    {p.architecture.apis.map((a, i) => <li key={i} style={{ marginBottom: '4px' }}>{a}</li>)}
                  </ul>
                </div>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>Infrastructure / Deployment</div>
                <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                  {p.architecture.infrastructure.map((inf, i) => <li key={i} style={{ marginBottom: '4px' }}>{inf}</li>)}
                </ul>
              </div>

              <div style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', padding: '16px', borderRadius: '10px' }}>
                <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--accent-orange)', textTransform: 'uppercase', marginBottom: '8px' }}>Architect Reasoning Notes</div>
                <ul style={{ paddingLeft: '18px', color: 'var(--text-secondary)', fontSize: '13px', lineHeight: 1.6 }}>
                  {p.architecture.architecture_notes.map((n, i) => <li key={i} style={{ marginBottom: '6px' }}>{n}</li>)}
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'tasks' && p.tasks && (
            <div style={{ background: 'rgba(5, 8, 17, 0.2)', border: '1px solid var(--border-dim)', padding: '24px', borderRadius: '14px' }}>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                Developer Checklist & Task Breakdown
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {p.tasks.map((task) => (
                  <div key={task.task_id} style={{ display: 'flex', alignItems: 'flex-start', gap: '14px', background: 'rgba(5, 8, 17, 0.3)', border: '1px solid var(--border-dim)', padding: '12px 16px', borderRadius: '8px' }}>
                    <div style={{
                      background: 'var(--bg-surface)',
                      border: '1px solid var(--border-bright)',
                      color: 'var(--accent-cyan)',
                      fontSize: '11px',
                      fontWeight: 700,
                      padding: '2px 8px',
                      borderRadius: '4px',
                      marginTop: '2px'
                    }}>
                      {task.task_id}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '13.5px', color: 'var(--text-primary)' }}>{task.description}</div>
                      <div style={{ display: 'flex', gap: '12px', marginTop: '6px', fontSize: '11px', color: 'var(--text-secondary)' }}>
                        <span>Category: <strong style={{ color: 'var(--text-primary)' }}>{task.category}</strong></span>
                        {task.depends_on && task.depends_on.length > 0 && (
                          <span>Dependencies: <strong style={{ color: 'var(--accent-orange)' }}>{task.depends_on.join(', ')}</strong></span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'flowchart' && p.flowchart && (
            <div style={{ background: 'rgba(5, 8, 17, 0.2)', border: '1px solid var(--border-dim)', padding: '24px', borderRadius: '14px' }}>
              <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                System Architecture Flowchart
              </h4>
              <MermaidRenderer chart={p.flowchart} />
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ActiveProjectView;
