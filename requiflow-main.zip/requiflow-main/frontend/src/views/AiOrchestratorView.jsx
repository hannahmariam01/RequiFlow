import React, { useState, useEffect } from 'react';

const MermaidRenderer = ({ chart }) => {
  const [svg, setSvg] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!chart || !window.mermaid) return;

    const renderChart = async () => {
      try {
        setError(null);
        window.mermaid.initialize({
          startOnLoad: false,
          theme: 'dark',
          securityLevel: 'loose',
          themeVariables: {
            background: '#0c1120',
            primaryColor: '#0f162a',
            primaryTextColor: '#e8edf8',
            lineColor: '#4f8cff',
            secondaryColor: '#1e293b',
            tertiaryColor: '#0f172a'
          }
        });
        
        // Defensive regex replacement to correct LLM-generated arrow-label syntax errors
        const sanitizedChart = chart
          .replace(/-->\|([^|]+)\|>/g, '-->|$1|')
          .replace(/-->\|([^|]+)\|/g, (match, label) => {
            const cleanLabel = label.replace(/[()\[\]{}"'\/]/g, '');
            return `-->|${cleanLabel}|`;
          });
        
        const id = 'mermaid-' + Math.floor(Math.random() * 100000);
        const { svg: renderedSvg } = await window.mermaid.render(id, sanitizedChart);
        setSvg(renderedSvg);
      } catch (err) {
        console.error('Mermaid render error:', err);
        setError('Flowchart visualization could not be rendered due to formatting constraints.');
      }
    };

    renderChart();
  }, [chart]);

  if (error) {
    return (
      <div style={{
        padding: '16px',
        border: '1px solid var(--accent-red)',
        borderRadius: '10px',
        color: 'var(--accent-red)',
        background: 'rgba(244, 63, 94, 0.05)',
        fontSize: '13px'
      }}>
        <div>⚠️ {error}</div>
        <pre style={{
          marginTop: '12px',
          fontFamily: 'monospace',
          fontSize: '11px',
          whiteSpace: 'pre-wrap',
          background: 'rgba(0,0,0,0.3)',
          padding: '10px',
          borderRadius: '6px'
        }}>{chart}</pre>
      </div>
    );
  }

  if (!svg) {
    return <div style={{ color: 'var(--text-secondary)', padding: '16px' }}>Initializing visual flowchart rendering...</div>;
  }

  return (
    <div 
      className="mermaid-svg-container" 
      dangerouslySetInnerHTML={{ __html: svg }} 
      style={{
        display: 'flex',
        justifyContent: 'center',
        background: 'rgba(12, 17, 32, 0.4)',
        padding: '24px',
        borderRadius: '14px',
        border: '1px solid var(--border-dim)',
        overflowX: 'auto',
        boxShadow: 'var(--shadow-card)'
      }}
    />
  );
};

const AiOrchestratorView = ({ onShowToast }) => {
  const [inputText, setInputText] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | clarifying | success
  const [activeStep, setActiveStep] = useState(0); // For progress tracking
  const [originalRequirements, setOriginalRequirements] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState('requirements'); // requirements | architecture | tasks | flowchart

  // Simulation steps list to animate agent steps
  const steps = [
    "Requirements analysis (RequirementUnderstandingAgent)",
    "Scanning content consistency & gaps (ClarificationAgent)",
    "Designing component architecture (ArchitectureAgent)",
    "Generating granular developer checklist (TaskBreakdownAgent)",
    "Structuring workflow diagrams (FlowchartAgent)",
    "Finalizing output packet"
  ];

  useEffect(() => {
    let interval;
    if (status === 'loading') {
      interval = setInterval(() => {
        setActiveStep((prev) => {
          if (prev < steps.length - 1) {
            return prev + 1;
          }
          return prev;
        });
      }, 3500);
    } else {
      setActiveStep(0);
    }
    return () => clearInterval(interval);
  }, [status]);

  const handleStartPipeline = async () => {
    if (!inputText.trim()) {
      onShowToast('warning', 'Please enter some requirements to begin.');
      return;
    }
    setStatus('loading');
    setActiveStep(0);
    onShowToast('info', 'AI agents are gathering. Beginning analysis...');

    try {
      const response = await fetch('http://localhost:5000/api/run-orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_text: inputText })
      });

      if (!response.ok) {
        throw new Error('API server returned error.');
      }

      const data = await response.json();
      if (data.error) {
        onShowToast('error', `Pipeline failed: ${data.error}`);
        setStatus('idle');
        return;
      }

      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        // Save requirements generated so far (we mock original_requirements based on the input text if needed)
        setOriginalRequirements({
          project_goal: "Generate project requirements based on input.",
          user_types: [],
          features: [],
          constraints: [],
          risks: [],
          missing_information: data.questions.map(q => q.question)
        });
        setStatus('clarifying');
        onShowToast('info', 'Clarification questions generated. Input required.');
      } else {
        setResults(data);
        setStatus('success');
        onShowToast('success', 'AI Pipeline complete! System architecture created.');
      }
    } catch (err) {
      console.error(err);
      onShowToast('error', 'Failed to communicate with the orchestrator backend.');
      setStatus('idle');
    }
  };

  const handleClarificationSubmit = async () => {
    setStatus('loading');
    setActiveStep(2); // Jump straight to refinement
    onShowToast('info', 'Merging clarifications and re-running agents...');

    const formattedAnswers = {
      answers: questions.map(q => ({
        question_id: q.id,
        answer: answers[q.id] || "No answer provided."
      }))
    };

    try {
      const response = await fetch('http://localhost:5000/api/run-orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          original_requirements: originalRequirements,
          user_answers: formattedAnswers
        })
      });

      if (!response.ok) {
        throw new Error('API server returned error.');
      }

      const data = await response.json();
      if (data.error) {
        onShowToast('error', `Refinement failed: ${data.error}`);
        setStatus('idle');
        return;
      }

      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setOriginalRequirements(data.requirements || originalRequirements);
        setStatus('clarifying');
        onShowToast('info', 'Additional clarification questions generated.');
      } else {
        setResults(data);
        setStatus('success');
        onShowToast('success', 'AI Pipeline complete! refined specifications designed.');
      }
    } catch (err) {
      console.error(err);
      onShowToast('error', 'Failed to submit clarifications to backend.');
      setStatus('idle');
    }
  };

  const handleReset = () => {
    setInputText('');
    setOriginalRequirements(null);
    setQuestions([]);
    setAnswers({});
    setResults(null);
    setStatus('idle');
  };

  return (
    <section className="view active" id="view-ai-orchestrator" aria-label="AI Orchestrator view">
      <div className="view-header">
        <h2 className="view-heading">AI Architect Orchestrator</h2>
      </div>

      <div className="active-project-container" style={{ minHeight: 'calc(100vh - 180px)' }}>
        {status === 'idle' && (
          <div className="apc-hero" style={{ padding: '30px' }}>
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '8px' }}>
                Run Collaborative Agent Pipeline
              </h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
                Enter your raw software requirements below. Our pipeline of agent specialists will parse your goal, detect missing information, clarify uncertainties, draft a technical architecture, break it down into developer tasks, and build a visual workflow.
              </p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label htmlFor="req-input-textarea" style={{ display: 'block', fontSize: '12px', color: 'var(--text-secondary)', fontWeight: 600, marginBottom: '8px' }}>
                Raw Project Requirements
              </label>
              <textarea
                id="req-input-textarea"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="e.g. Build a doctor's appointment application. Patients must pay a booking fee of $50, search by specialty, and schedule slots. Use PostgreSQL database and complete in 3 weeks."
                style={{
                  width: '100%',
                  height: '140px',
                  background: 'rgba(5, 8, 17, 0.6)',
                  border: '1px solid var(--border-bright)',
                  borderRadius: '10px',
                  color: 'var(--text-primary)',
                  padding: '14px',
                  fontFamily: 'inherit',
                  fontSize: '13.5px',
                  resize: 'none',
                  outline: 'none'
                }}
              />
            </div>

            <button className="btn-primary" onClick={handleStartPipeline} style={{ padding: '10px 24px' }}>
              Assemble Agents & Run Pipeline
            </button>
          </div>
        )}

        {status === 'loading' && (
          <div className="apc-hero" style={{ padding: '60px 40px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{
              width: '60px',
              height: '60px',
              border: '4px solid var(--border-dim)',
              borderTopColor: 'var(--accent-blue)',
              borderRadius: '50%',
              animation: 'spin 1.2s linear infinite',
              marginBottom: '24px'
            }} />
            <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '12px' }}>
              Agentic Processing...
            </h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '13.5px', maxWidth: '400px', marginBottom: '30px' }}>
              Our LLM-powered system specialists are working together in the background.
            </p>

            <div style={{ width: '100%', maxWidth: '500px', background: 'rgba(5, 8, 17, 0.4)', borderRadius: '14px', border: '1px solid var(--border-dim)', padding: '20px', textAlign: 'left' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)', fontWeight: 600, marginBottom: '14px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Pipeline Progress Log
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {steps.map((stepText, idx) => {
                  const isActive = idx === activeStep;
                  const isDone = idx < activeStep;
                  return (
                    <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px', opacity: isActive ? 1 : isDone ? 0.7 : 0.4 }}>
                      <div style={{
                        width: '18px',
                        height: '18px',
                        borderRadius: '50%',
                        background: isDone ? 'var(--accent-green)' : isActive ? 'var(--accent-blue)' : 'var(--text-muted)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '10px',
                        color: '#fff',
                        fontWeight: 700
                      }}>
                        {isDone ? '✓' : idx + 1}
                      </div>
                      <span style={{ fontSize: '13px', color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: isActive ? 600 : 400 }}>
                        {stepText}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {status === 'clarifying' && (
          <div className="apc-hero" style={{ padding: '30px' }}>
            <div style={{ marginBottom: '24px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '16px' }}>
              <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--accent-orange)', marginBottom: '6px' }}>
                🔍 Clarification Required
              </h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
                The agents detected gaps or uncertainties in your requirements. Provide clarifications below to continue the process.
              </p>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginBottom: '30px' }}>
              {questions.map((q) => (
                <div key={q.id} style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', borderRadius: '10px', padding: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>Question {q.id}</span>
                    <span style={{ fontSize: '11px', textTransform: 'uppercase', color: 'var(--accent-blue)', fontWeight: 600 }}>{q.category}</span>
                  </div>
                  <div style={{ fontSize: '13.5px', color: 'var(--text-secondary)', marginBottom: '12px' }}>{q.question}</div>
                  <input
                    type="text"
                    value={answers[q.id] || ''}
                    onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                    placeholder="Type your response to clarify this point..."
                    style={{
                      width: '100%',
                      background: 'rgba(0,0,0,0.2)',
                      border: '1px solid var(--border-bright)',
                      borderRadius: '6px',
                      color: 'var(--text-primary)',
                      padding: '8px 12px',
                      fontSize: '13px',
                      outline: 'none'
                    }}
                  />
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: '12px' }}>
              <button className="btn-primary" onClick={handleClarificationSubmit}>
                Submit Answers & Continue
              </button>
              <button className="btn-secondary" onClick={handleReset}>
                Cancel Pipeline
              </button>
            </div>
          </div>
        )}

        {status === 'success' && results && (
          <div>
            {/* View Header with back buttons */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', background: 'var(--bg-card)', padding: '16px 24px', borderRadius: '14px', border: '1px solid var(--border-dim)' }}>
              <div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--accent-green)' }}>✓ Analysis Complete</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '12px' }}>Review the synthesized project requirements, architecture design, and visual flowchart.</p>
              </div>
              <button className="btn-secondary" onClick={handleReset} style={{ padding: '6px 14px', fontSize: '12px' }}>
                Run New Analysis
              </button>
            </div>

            {/* Navigation Tabs */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', overflowX: 'auto', paddingBottom: '4px' }}>
              {[
                { id: 'requirements', label: 'Requirements Spec' },
                { id: 'architecture', label: 'Tech Architecture' },
                { id: 'tasks', label: 'Task Breakdown' },
                { id: 'flowchart', label: 'System Flowchart' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  style={{
                    padding: '8px 16px',
                    fontSize: '13px',
                    fontWeight: 600,
                    borderRadius: '8px',
                    border: '1px solid',
                    borderColor: activeTab === tab.id ? 'var(--border-accent)' : 'var(--border-dim)',
                    background: activeTab === tab.id ? 'rgba(79, 140, 255, 0.1)' : 'var(--bg-card)',
                    color: activeTab === tab.id ? 'var(--text-accent)' : 'var(--text-secondary)',
                    cursor: 'pointer',
                    outline: 'none',
                    transition: 'var(--transition)'
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab content panel */}
            <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: '14px', padding: '24px', minHeight: '400px' }}>
              {activeTab === 'requirements' && (
                <div>
                  <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                    Requirements Specification
                  </h4>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    <div>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Project Goal</div>
                      <div style={{ fontSize: '14px', color: 'var(--text-primary)', lineHeight: 1.6 }}>{results.requirements.project_goal}</div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                      <div>
                        <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>User Roles</div>
                        <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13.5px' }}>
                          {results.requirements.user_types.map((u, i) => <li key={i} style={{ marginBottom: '4px' }}>{u}</li>)}
                        </ul>
                      </div>
                      <div>
                        <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Constraints</div>
                        <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13.5px' }}>
                          {results.requirements.constraints.map((c, i) => <li key={i} style={{ marginBottom: '4px' }}>{c}</li>)}
                        </ul>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>Key Functional Features</div>
                      <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13.5px' }}>
                        {results.requirements.features.map((f, i) => <li key={i} style={{ marginBottom: '4px' }}>{f}</li>)}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'architecture' && (
                <div>
                  <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                    Technical Architecture Design
                  </h4>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px', marginBottom: '24px' }}>
                    {[
                      { title: 'Frontend Stack', val: results.architecture.frontend, color: 'var(--accent-blue)' },
                      { title: 'Backend Runtime', val: results.architecture.backend, color: 'var(--accent-cyan)' },
                      { title: 'Database Configuration', val: results.architecture.database, color: 'var(--accent-purple)' }
                    ].map((box, i) => (
                      <div key={i} style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', padding: '16px', borderRadius: '10px' }}>
                        <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '6px' }}>{box.title}</div>
                        <div style={{ fontSize: '13.5px', color: box.color, fontWeight: 600 }}>{box.val}</div>
                      </div>
                    ))}
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>
                    <div>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>Integrations & Services</div>
                      <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                        {results.architecture.services.map((s, i) => <li key={i} style={{ marginBottom: '4px' }}>{s}</li>)}
                      </ul>
                    </div>
                    <div>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>API Interfaces</div>
                      <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                        {results.architecture.apis.map((a, i) => <li key={i} style={{ marginBottom: '4px' }}>{a}</li>)}
                      </ul>
                    </div>
                  </div>

                  <div style={{ marginBottom: '20px' }}>
                    <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '8px' }}>Infrastructure / Deployment</div>
                    <ul style={{ paddingLeft: '18px', color: 'var(--text-primary)', fontSize: '13px' }}>
                      {results.architecture.infrastructure.map((inf, i) => <li key={i} style={{ marginBottom: '4px' }}>{inf}</li>)}
                    </ul>
                  </div>

                  <div style={{ background: 'rgba(5, 8, 17, 0.4)', border: '1px solid var(--border-dim)', padding: '16px', borderRadius: '10px' }}>
                    <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--accent-orange)', textTransform: 'uppercase', marginBottom: '8px' }}>Architect Reasoning Notes</div>
                    <ul style={{ paddingLeft: '18px', color: 'var(--text-secondary)', fontSize: '13px', lineHeight: 1.6 }}>
                      {results.architecture.architecture_notes.map((n, i) => <li key={i} style={{ marginBottom: '6px' }}>{n}</li>)}
                    </ul>
                  </div>
                </div>
              )}

              {activeTab === 'tasks' && (
                <div>
                  <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                    Developer Checklist & Task Breakdown
                  </h4>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {results.tasks.map((task) => (
                      <div key={task.task_id} style={{ display: 'flex', alignItems: 'flex-start', gap: '14px', background: 'rgba(5, 8, 17, 0.3)', border: '1px solid var(--border-dim)', padding: '12px 16px', borderRadius: '8px' }}>
                        <div style={{
                          background: 'var(--bg-surface)',
                          border: '1px solid var(--border-bright)',
                          color: 'var(--accent-cyan)',
                          fontSize: '11px',
                          fontWeight: 700,
                          padding: '2px 8px',
                          borderRadius: '4px',
                          marginTop: '2px'
                        }}>
                          {task.task_id}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '13.5px', color: 'var(--text-primary)' }}>{task.description}</div>
                          <div style={{ display: 'flex', gap: '12px', marginTop: '6px', fontSize: '11px', color: 'var(--text-secondary)' }}>
                            <span>Category: <strong style={{ color: 'var(--text-primary)' }}>{task.category}</strong></span>
                            {task.depends_on && task.depends_on.length > 0 && (
                              <span>Dependencies: <strong style={{ color: 'var(--accent-orange)' }}>{task.depends_on.join(', ')}</strong></span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'flowchart' && (
                <div>
                  <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '16px', borderBottom: '1px solid var(--border-dim)', paddingBottom: '10px' }}>
                    System Architecture Flowchart
                  </h4>
                  <MermaidRenderer chart={results.flowchart} />
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default AiOrchestratorView;
