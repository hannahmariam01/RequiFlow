import React, { useState } from 'react';

const SettingsView = ({ onShowToast }) => {
  const [emailNotif, setEmailNotif] = useState(true);
  const [aiAlerts, setAiAlerts] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(false);
  const [autoGen, setAutoGen] = useState(true);
  const [smartSuggest, setSmartSuggest] = useState(true);
  const [twoFactor, setTwoFactor] = useState(false);

  const handleToggle = (setter, value, label) => {
    setter(!value);
    onShowToast('info', `${label} updated`);
  };

  return (
    <section className="view active" id="view-settings" aria-label="Settings view">
      <div className="view-header">
        <h2 className="view-heading">Settings</h2>
      </div>
      <div className="settings-container" id="settings-container">
        <div className="settings-section">
          <div className="settings-section-title">Notifications</div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Email notifications</div>
              <div className="settings-row-desc">Receive project updates via email</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={emailNotif}
                onChange={() => handleToggle(setEmailNotif, emailNotif, 'Email notifications')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">AI analysis alerts</div>
              <div className="settings-row-desc">Get notified when AI completes analysis</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={aiAlerts}
                onChange={() => handleToggle(setAiAlerts, aiAlerts, 'AI alerts')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Weekly digest</div>
              <div className="settings-row-desc">Summary of weekly activity</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={weeklyDigest}
                onChange={() => handleToggle(setWeeklyDigest, weeklyDigest, 'Weekly digest')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </div>

        <div className="settings-section">
          <div className="settings-section-title">AI Preferences</div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Auto-generate user stories</div>
              <div className="settings-row-desc">AI automatically generates stories on project creation</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={autoGen}
                onChange={() => handleToggle(setAutoGen, autoGen, 'Auto-generate')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Smart document suggestions</div>
              <div className="settings-row-desc">AI suggests relevant document templates</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={smartSuggest}
                onChange={() => handleToggle(setSmartSuggest, smartSuggest, 'Smart suggestions')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </div>

        <div className="settings-section">
          <div className="settings-section-title">Account</div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Hannah Mariam</div>
              <div className="settings-row-desc">hannah.mariam@company.com · Product Manager</div>
            </div>
            <button className="btn-secondary" onClick={() => onShowToast('info', 'Profile editing coming soon')} style={{ fontSize: '12px', padding: '6px 14px' }}>
              Edit profile
            </button>
          </div>
          <div className="settings-row">
            <div className="settings-row-info">
              <div className="settings-row-label">Two-factor authentication</div>
              <div className="settings-row-desc">Add an extra layer of security</div>
            </div>
            <label className="toggle">
              <input
                type="checkbox"
                checked={twoFactor}
                onChange={() => handleToggle(setTwoFactor, twoFactor, '2FA setting')}
              />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SettingsView;
