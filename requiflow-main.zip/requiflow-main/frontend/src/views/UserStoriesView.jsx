import React from 'react';

const UserStoriesView = ({
  userStories,
  onGenerateStories
}) => {
  return (
    <section className="view active" id="view-user-stories" aria-label="User stories view">
      <div className="view-header">
        <h2 className="view-heading">User Stories</h2>
        <button className="btn-primary" onClick={onGenerateStories} style={{ background: 'linear-gradient(135deg, var(--accent-blue), #6366f1)', border: 'none' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '6px' }}>
            <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m0-12.728l.707.707m11.314 11.314l.707.707M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10z"/>
          </svg>
          Generate with AI
        </button>
      </div>
      <div className="stories-container" id="stories-container">
        {userStories.map((s) => (
          <div key={s.id} className="story-card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div style={{ display: 'flex', width: '100%', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <div className="story-id">{s.id}</div>
                <div className="story-body">
                  <div className="story-text" dangerouslySetInnerHTML={{ __html: s.text }}></div>
                  <div className="story-tags">
                    {s.epic && (
                      <span className="story-tag" style={{ background: 'rgba(79, 140, 255, 0.12)', color: 'var(--accent-blue)', borderColor: 'rgba(79, 140, 255, 0.25)' }}>
                        📁 {s.epic}
                      </span>
                    )}
                    {s.tags.map((t, idx) => (
                      <span key={idx} className="story-tag">{t}</span>
                    ))}
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px', flexShrink: 0 }}>
                <span className={`story-priority ${s.priority}`}>
                  {s.priority.charAt(0).toUpperCase() + s.priority.slice(1)}
                </span>
                {s.story_points && (
                  <span style={{
                    fontSize: '10.5px',
                    fontWeight: 700,
                    background: 'rgba(34, 211, 165, 0.1)',
                    color: 'var(--accent-green)',
                    border: '1px solid rgba(34, 211, 165, 0.2)',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    fontFamily: 'monospace'
                  }}>
                    ⚡ {s.story_points} SP
                  </span>
                )}
              </div>
            </div>

            {s.acceptance_criteria && s.acceptance_criteria.length > 0 && (
              <div style={{
                marginTop: '8px',
                padding: '12px 16px',
                background: 'rgba(255, 255, 255, 0.02)',
                border: '1px solid var(--border-dim)',
                borderRadius: '8px'
              }}>
                <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>
                  Acceptance Criteria:
                </div>
                <ul style={{ listStyleType: 'none', paddingLeft: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '5px' }}>
                  {s.acceptance_criteria.map((ac, idx) => (
                    <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '12.5px', color: 'var(--text-secondary)' }}>
                      <span style={{ color: 'var(--accent-green)', fontWeight: 'bold', marginTop: '2px', fontSize: '11px' }}>✓</span>
                      <span>{ac}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
        {userStories.length === 0 && (
          <p style={{ color: 'var(--text-muted)', fontSize: '13px', textAlign: 'center', padding: '40px 0' }}>
            No user stories available. Click "Generate with AI" to create one.
          </p>
        )}
      </div>
    </section>
  );
};

export default UserStoriesView;
