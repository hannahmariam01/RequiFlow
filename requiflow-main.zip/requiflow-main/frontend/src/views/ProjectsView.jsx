import React from 'react';
import ProjectIcon from '../components/ProjectIcon';

const ProjectsView = ({
  projects,
  searchQuery,
  onOpenProject,
  onNewProjectClick
}) => {
  const filteredProjects = projects.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="view active" id="view-projects" aria-label="Projects view">
      <div className="view-header">
        <h2 className="view-heading">All Projects</h2>
      </div>
      <div className="projects-grid" id="projects-grid">
        {filteredProjects.map((p) => (
          <div
            key={p.id}
            className="project-grid-card"
            onClick={() => onOpenProject(p.id)}
            tabIndex={0}
            role="button"
            aria-label={`Open ${p.name}`}
            onKeyDown={(e) => { if (e.key === 'Enter') onOpenProject(p.id); }}
          >
            <div className="pgc-header">
              <div className={`pgc-icon project-icon ${p.icon}`}>
                <ProjectIcon name={p.icon} />
              </div>
              <span className={`project-status ${p.status}`}>
                {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
              </span>
            </div>
            <div className="pgc-name">{p.name}</div>
            <div className="pgc-desc">{p.desc}</div>
            <div className="project-progress-bar" role="progressbar" aria-valuenow={p.progress} aria-valuemin="0" aria-valuemax="100">
              <div className={`progress-fill ${p.status}`} style={{ width: `${p.progress}%` }}></div>
            </div>
            <div className="pgc-footer" style={{ marginTop: '10px' }}>
              <span className="pgc-progress">
                <span>{p.progress}%</span> complete
              </span>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{p.updatedLabel}</span>
            </div>
          </div>
        ))}
        {filteredProjects.length === 0 && (
          <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: 'var(--text-muted)', padding: '40px 0' }}>
            No projects match your search query.
          </p>
        )}
      </div>
    </section>
  );
};

export default ProjectsView;
