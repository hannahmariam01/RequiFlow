import React from 'react';

const AiAgentsView = ({
  agents,
  onToggleAgentStatus
}) => {
  return (
    <section className="view active" id="view-ai-agents" aria-label="AI agents view">
      <div className="view-header">
        <h2 className="view-heading">AI Agents</h2>
      </div>
      <div className="agents-grid" id="agents-grid-view">
        {agents.map((a) => (
          <div
            key={a.id}
            className="agent-grid-card"
            tabIndex={0}
            onClick={() => onToggleAgentStatus(a.id)}
            onKeyDown={(e) => { if (e.key === 'Enter') onToggleAgentStatus(a.id); }}
          >
            <div className={`agc-avatar agent-avatar ${a.cls}`}>{a.initials}</div>
            <div className="agc-name">{a.name}</div>
            <div className="agc-role">{a.role}</div>
            <span className={`agc-status-badge ${a.status}`}>
              {a.status === 'active' && (
                <span className="live-dot" style={{ width: '6px', height: '6px' }}></span>
              )}
              {a.status === 'active' ? (a.task || 'Active') : 'Standby'}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
};

export default AiAgentsView;
