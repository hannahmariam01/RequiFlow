import React from 'react';
import AnimatedCounter from '../components/AnimatedCounter';
import ProjectIcon from '../components/ProjectIcon';

const DashboardView = ({
  projects,
  userStories,
  documents,
  agents,
  onViewChange,
  onOpenProject,
  onDownloadProject,
  onToggleAgentStatus
}) => {
  const pendingApprovalsCount = projects.filter(p => p.status === 'pending').length;

  const recentActivities = projects.slice(0, 4).map((p, i) => ({
    id: p.id,
    type: p.status === 'pending' ? 'warn' : p.status === 'approved' ? 'approved' : p.status === 'generated' ? 'doc' : 'ai',
    text: `<strong>${p.name}</strong> — status: <span class="activity-highlight">${p.status.charAt(0).toUpperCase() + p.status.slice(1)}</span>`,
    time: p.updatedLabel,
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
        <polyline points="13 2 13 9 20 9"></polyline>
      </svg>
    )
  }));

  return (
    <section className="view active" id="view-dashboard" aria-label="Dashboard view">
      {/* Stats row */}
      <div className="stats-grid">
        <div className="stat-card" id="stat-total-projects">
          <div className="stat-label">Total projects</div>
          <div className="stat-value">
            <AnimatedCounter value={projects.length} />
          </div>
          <div className="stat-delta positive">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="18 15 12 9 6 15"></polyline>
            </svg>
            2 this month
          </div>
          <div className="stat-glow" aria-hidden="true"></div>
        </div>
        <div className="stat-card" id="stat-user-stories">
          <div className="stat-label">User stories generated</div>
          <div className="stat-value">
            <AnimatedCounter value={34 + userStories.length} />
          </div>
          <div className="stat-delta positive">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="18 15 12 9 6 15"></polyline>
            </svg>
            18 this week
          </div>
          <div className="stat-glow" aria-hidden="true"></div>
        </div>
        <div className="stat-card" id="stat-docs">
          <div className="stat-label">Documents exported</div>
          <div className="stat-value">
            <AnimatedCounter value={documents.length} />
          </div>
          <div className="stat-delta neutral">BRD, SRS, User Stories</div>
          <div className="stat-glow" aria-hidden="true"></div>
        </div>
        <div className="stat-card warning" id="stat-approvals">
          <div className="stat-label">Pending approvals</div>
          <div className="stat-value">
            <AnimatedCounter value={pendingApprovalsCount} />
          </div>
          <div className="stat-delta warn">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            Needs review
          </div>
          <div className="stat-glow warn" aria-hidden="true"></div>
        </div>
      </div>

      {/* Recent projects */}
      <div className="section-header">
        <h2 className="section-title">Recent projects</h2>
        <button className="link-btn" onClick={() => onViewChange('projects')}>View all →</button>
      </div>

      <div className="projects-list" id="projects-list" role="list">
        {projects.length === 0 ? (
          <div className="empty-state" style={{ gridColumn: '1 / -1', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '3rem 1rem', gap: '1rem', opacity: 0.7 }}>
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.4 }}>
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
              <line x1="12" y1="11" x2="12" y2="17"></line>
              <line x1="9" y1="14" x2="15" y2="14"></line>
            </svg>
            <p style={{ margin: 0, fontSize: '0.95rem', textAlign: 'center', color: 'var(--text-secondary)' }}>No projects yet. Click <strong>+ New Project</strong> to get started.</p>
          </div>
        ) : (
          projects.slice(0, 4).map((p) => (
          <article
            key={p.id}
            className="project-card"
            role="listitem"
            id={`project-${p.id}`}
            tabIndex={0}
            onClick={() => onOpenProject(p.id)}
            onKeyDown={(e) => { if (e.key === 'Enter') onOpenProject(p.id); }}
          >
            <div className="project-card-inner">
              <div className={`project-icon ${p.icon}`} aria-hidden="true">
                <ProjectIcon name={p.icon} />
              </div>
              <div className="project-info">
                <h3 className="project-name">{p.name}</h3>
                <p className="project-desc">{p.desc}</p>
                <div className="project-meta">
                  <span className={`project-status ${p.status}`}>
                    {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                  </span>
                  <span className="project-updated">{p.updatedLabel}</span>
                </div>
                <div className="project-progress-bar" role="progressbar" aria-valuenow={p.progress} aria-valuemin="0" aria-valuemax="100" aria-label={`Project progress ${p.progress}%`}>
                  <div className={`progress-fill ${p.status}`} style={{ width: `${p.progress}%` }}></div>
                </div>
              </div>
              {p.id === 'edtech' ? (
                <button
                  className="project-action-btn download"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDownloadProject(p.id);
                  }}
                  aria-label={`Download ${p.name}`}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                  </svg>
                </button>
              ) : (
                <button className="project-action-btn" aria-label={`Open ${p.name}`}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </button>
              )}
            </div>
          </article>
          ))
        )}
      </div>

      {/* Bottom row: Recent activity + AI agents on call */}
      <div className="bottom-row">
        {/* Recent activity */}
        <div className="card activity-card">
          <h2 className="card-title">Recent activity</h2>
          {recentActivities.length === 0 ? (
            <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', margin: '1rem 0', opacity: 0.7 }}>
              No activity yet. Add a project to get started.
            </p>
          ) : (
            <ul className="activity-list" id="activity-list" role="list">
              {recentActivities.map((act) => (
                <li key={act.id} className="activity-item" role="listitem">
                  <div className={`activity-icon ${act.type}`} aria-hidden="true">
                    {act.icon}
                  </div>
                  <div className="activity-body">
                    <p dangerouslySetInnerHTML={{ __html: act.text }}></p>
                    <span className="activity-time">{act.time}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* AI agents on call */}
        <div className="card agents-card">
          <div className="agents-header">
            <h2 className="card-title">AI agents on call</h2>
            <span className="agents-live-badge">
              <span className="live-dot" aria-hidden="true"></span>
              Live
            </span>
          </div>
          <ul className="agents-list" id="agents-list" role="list">
            {agents.map((a) => (
              <li
                key={a.id}
                className={`agent-item ${a.status === 'active' ? 'active-agent' : ''}`}
                role="listitem"
                tabIndex={0}
                onClick={() => onToggleAgentStatus(a.id)}
                onKeyDown={(e) => { if (e.key === 'Enter') onToggleAgentStatus(a.id); }}
              >
                <div className={`agent-avatar ${a.cls}`} aria-hidden="true">{a.initials}</div>
                <div className="agent-info">
                  <span className="agent-name">{a.name}</span>
                  <span className={`agent-status ${a.status}`}>
                    {a.status === 'active' ? `Active · ${a.task || 'Working'}` : 'Standby'}
                  </span>
                </div>
                <div className={`agent-indicator ${a.status}`}></div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export default DashboardView;
