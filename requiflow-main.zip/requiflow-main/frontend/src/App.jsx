import React, { useState, useEffect } from 'react';
import LandingPage from './LandingPage';
import './LandingPage.css';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import NotificationsPanel from './components/NotificationsPanel';
import NewProjectModal from './components/NewProjectModal';
import ToastContainer from './components/ToastContainer';

// Import Views
import DashboardView from './views/DashboardView';
import ProjectsView from './views/ProjectsView';
import ActiveProjectView from './views/ActiveProjectView';
import UserStoriesView from './views/UserStoriesView';
import DocumentsView from './views/DocumentsView';
import AiAgentsView from './views/AiAgentsView';
import SettingsView from './views/SettingsView';
import AuthView from './views/AuthView';
import VerifyEmailView from './views/VerifyEmailView';
import { Routes, Route, Navigate } from 'react-router-dom';

const App = () => {

  // --- States ---
  const [projects, setProjects] = useState(() => {
    const saved = localStorage.getItem('requiflow_projects');
    return saved ? JSON.parse(saved) : [
      {
        id: 'cloud-infra',
        name: 'Cloud Infrastructure Migration',
        desc: 'Migrate on-premise servers to AWS with auto-scaling and CI/CD pipelines',
        type: 'platform',
        status: 'analyzed',
        progress: 65,
        icon: 'edtech',
        updatedLabel: 'Updated 1h ago',
        stories: 14,
        docs: 3,
      },
      {
        id: 'cybersec-platform',
        name: 'Cybersecurity Monitoring Platform',
        desc: 'Real-time threat detection and SIEM dashboard for enterprise networks',
        type: 'web',
        status: 'approved',
        progress: 88,
        icon: 'healthcare',
        updatedLabel: 'Updated 3h ago',
        stories: 20,
        docs: 4,
      },
      {
        id: 'devops-portal',
        name: 'DevOps Self-Service Portal',
        desc: 'Internal portal for provisioning environments, pipelines, and deployments',
        type: 'web',
        status: 'generated',
        progress: 45,
        icon: 'ecommerce',
        updatedLabel: 'Yesterday',
        stories: 10,
        docs: 2,
      },
      {
        id: 'it-helpdesk',
        name: 'IT Helpdesk & Asset Management',
        desc: 'Ticketing system with AI triage, SLA tracking, and hardware inventory',
        type: 'platform',
        status: 'pending',
        progress: 20,
        icon: 'fintech',
        updatedLabel: '2 days ago',
        stories: 6,
        docs: 1,
      },
      {
        id: 'ecommerce',
        name: 'E-Commerce Platform',
        desc: 'Multi-vendor marketplace with AI recommendations',
        type: 'platform',
        status: 'analyzed',
        progress: 72,
        icon: 'ecommerce',
        updatedLabel: 'Updated 2h ago',
        stories: 18,
        docs: 3,
      },
      {
        id: 'healthcare',
        name: 'Healthcare Portal',
        desc: 'Patient records and teleconsultation system',
        type: 'web',
        status: 'approved',
        progress: 95,
        icon: 'healthcare',
        updatedLabel: 'Updated yesterday',
        stories: 12,
        docs: 2,
      },
      {
        id: 'edtech',
        name: 'EdTech LMS',
        desc: 'Learning management system with video delivery',
        type: 'platform',
        status: 'generated',
        progress: 60,
        icon: 'edtech',
        updatedLabel: '2 days ago',
        stories: 8,
        docs: 1,
      },
      {
        id: 'fintech',
        name: 'Fintech App',
        desc: 'Digital banking with real-time payment processing',
        type: 'mobile',
        status: 'pending',
        progress: 30,
        icon: 'fintech',
        updatedLabel: '3 days ago',
        stories: 4,
        docs: 1,
      },
    ];
  });

  const [userStories, setUserStories] = useState(() => {
    const saved = localStorage.getItem('requiflow_user_stories');
    return saved ? JSON.parse(saved) : [
      {
        id: 'US-001',
        projectId: 'cloud-infra',
        text: 'As a <strong>DevOps engineer</strong>, I want to migrate legacy workloads to AWS EC2 so that I can reduce on-premise hardware costs.',
        tags: ['Cloud', 'AWS', 'Migration'],
        priority: 'high',
      },
      {
        id: 'US-002',
        projectId: 'cloud-infra',
        text: 'As a <strong>system administrator</strong>, I want auto-scaling policies configured so that the infrastructure handles traffic spikes automatically.',
        tags: ['Cloud', 'Auto-Scaling', 'DevOps'],
        priority: 'high',
      },
      {
        id: 'US-003',
        projectId: 'cybersec-platform',
        text: 'As a <strong>security analyst</strong>, I want real-time alerts for anomalous network activity so that I can respond to threats within minutes.',
        tags: ['Security', 'SIEM', 'Alerts'],
        priority: 'high',
      },
      {
        id: 'US-004',
        projectId: 'cybersec-platform',
        text: 'As a <strong>CISO</strong>, I want an executive dashboard showing threat severity trends so that I can report risk posture to the board.',
        tags: ['Security', 'Dashboard', 'Reporting'],
        priority: 'medium',
      },
      {
        id: 'US-005',
        projectId: 'devops-portal',
        text: 'As a <strong>developer</strong>, I want to self-provision staging environments via a portal so that I can test features without waiting for ops approval.',
        tags: ['DevOps', 'Self-Service', 'Automation'],
        priority: 'high',
      },
      {
        id: 'US-006',
        projectId: 'devops-portal',
        text: 'As a <strong>release manager</strong>, I want one-click deployment pipelines so that I can ship releases faster with fewer manual steps.',
        tags: ['DevOps', 'CI/CD', 'Pipeline'],
        priority: 'medium',
      },
      {
        id: 'US-007',
        projectId: 'it-helpdesk',
        text: 'As an <strong>IT support agent</strong>, I want AI to auto-triage incoming tickets by category and priority so that I can focus on critical issues first.',
        tags: ['Helpdesk', 'AI', 'Triage'],
        priority: 'high',
      },
      {
        id: 'US-008',
        projectId: 'it-helpdesk',
        text: 'As an <strong>IT manager</strong>, I want a hardware asset inventory with lifecycle tracking so that I can plan procurement and avoid downtime.',
        tags: ['Helpdesk', 'Assets', 'Inventory'],
        priority: 'medium',
      },
      { id: 'US-009', projectId: 'ecommerce', text: 'As a <strong>buyer</strong>, I want to browse products by category so that I can find items quickly.', tags: ['E-Commerce', 'Browse', 'UX'], priority: 'high' },
      { id: 'US-010', projectId: 'ecommerce', text: 'As a <strong>seller</strong>, I want to list products with AI-generated descriptions so that I can save time.', tags: ['E-Commerce', 'AI', 'Seller'], priority: 'medium' },
      { id: 'US-011', projectId: 'healthcare', text: 'As a <strong>patient</strong>, I want to book a teleconsultation so that I can consult a doctor from home.', tags: ['Healthcare', 'Booking', 'Telehealth'], priority: 'high' },
      { id: 'US-012', projectId: 'healthcare', text: 'As a <strong>doctor</strong>, I want to view patient records before a session so that I can prepare properly.', tags: ['Healthcare', 'Records', 'Doctor'], priority: 'high' },
      { id: 'US-013', projectId: 'edtech', text: 'As a <strong>student</strong>, I want to resume a video lecture from where I left off so that I can learn at my own pace.', tags: ['EdTech', 'Video', 'UX'], priority: 'medium' },
      { id: 'US-014', projectId: 'edtech', text: 'As an <strong>instructor</strong>, I want to upload course materials so that students can access them anytime.', tags: ['EdTech', 'Content', 'Instructor'], priority: 'low' },
      { id: 'US-015', projectId: 'fintech', text: 'As a <strong>user</strong>, I want to send money instantly to contacts so that I can pay quickly and securely.', tags: ['Fintech', 'Payments', 'UX'], priority: 'high' },
      { id: 'US-016', projectId: 'fintech', text: 'As a <strong>user</strong>, I want to receive real-time notifications for transactions so that I can track my spending.', tags: ['Fintech', 'Notifications', 'Security'], priority: 'medium' },
    ];
  });

  const [documents, setDocuments] = useState(() => {
    const saved = localStorage.getItem('requiflow_documents');
    return saved ? JSON.parse(saved) : [
      { id: 'doc-1', name: 'BRD',         fullName: 'Business Requirements Document',       projectId: 'cloud-infra',       icon: '📄', size: '1.9 MB', date: '1h ago' },
      { id: 'doc-2', name: 'SRS',         fullName: 'Software Requirements Specification',  projectId: 'cloud-infra',       icon: '📋', size: '1.4 MB', date: '1h ago' },
      { id: 'doc-3', name: 'User Stories',fullName: 'User Story Document',                  projectId: 'cloud-infra',       icon: '📝', size: '620 KB', date: '1h ago' },
      { id: 'doc-4', name: 'BRD',         fullName: 'Business Requirements Document',       projectId: 'cybersec-platform', icon: '📄', size: '2.2 MB', date: '3h ago' },
      { id: 'doc-5', name: 'SRS',         fullName: 'Software Requirements Specification',  projectId: 'cybersec-platform', icon: '📋', size: '1.7 MB', date: '3h ago' },
      { id: 'doc-6', name: 'User Stories',fullName: 'User Story Document',                  projectId: 'cybersec-platform', icon: '📝', size: '840 KB', date: '3h ago' },
      { id: 'doc-7', name: 'Test Plan',   fullName: 'Quality Assurance Test Plan',          projectId: 'cybersec-platform', icon: '🧪', size: '510 KB', date: '3h ago' },
      { id: 'doc-8', name: 'BRD',         fullName: 'Business Requirements Document',       projectId: 'devops-portal',     icon: '📄', size: '1.1 MB', date: 'Yesterday' },
      { id: 'doc-9', name: 'SRS',         fullName: 'Software Requirements Specification',  projectId: 'devops-portal',     icon: '📋', size: '980 KB', date: 'Yesterday' },
      { id: 'doc-10',name: 'BRD',         fullName: 'Business Requirements Document',       projectId: 'it-helpdesk',       icon: '📄', size: '760 KB', date: '2 days ago' },
      { id: 'doc-11', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'ecommerce', icon: '📄', size: '2.4 MB', date: '2h ago' },
      { id: 'doc-12', name: 'SRS', fullName: 'Software Requirements Specification', projectId: 'ecommerce', icon: '📋', size: '1.8 MB', date: '2h ago' },
      { id: 'doc-13', name: 'User Stories', fullName: 'User Story Document', projectId: 'ecommerce', icon: '📝', size: '540 KB', date: '2h ago' },
      { id: 'doc-14', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'healthcare', icon: '📄', size: '1.6 MB', date: 'Yesterday' },
      { id: 'doc-15', name: 'SRS', fullName: 'Software Requirements Specification', projectId: 'healthcare', icon: '📋', size: '1.1 MB', date: 'Yesterday' },
      { id: 'doc-16', name: 'BRD', fullName: 'Business Requirements Document', projectId: 'edtech', icon: '📄', size: '980 KB', date: '2 days ago' },
      { id: 'doc-17', name: 'User Stories', fullName: 'User Story Document', projectId: 'fintech', icon: '📝', size: '320 KB', date: '3 days ago' },
    ];
  });

  const [agents, setAgents] = useState([
    { id: 'ba',  initials: 'BA', name: 'Business Analyst',    role: 'Requirements Analysis & Elicitation',  status: 'active',  task: 'Analyzing Cloud Infrastructure requirements',      cls: 'ba' },
    { id: 'pm',  initials: 'PM', name: 'Product Manager',     role: 'Backlog & Prioritization',             status: 'active',  task: 'Prioritizing IT Helpdesk user stories',           cls: 'pm' },
    { id: 'sa',  initials: 'SA', name: 'Solution Architect',  role: 'Technical Architecture & Cloud Design', status: 'active',  task: 'Designing DevOps Portal architecture',            cls: 'sa' },
    { id: 'sec', initials: 'SC', name: 'Security Analyst',    role: 'Threat Modeling & Compliance Review',  status: 'active',  task: 'Reviewing Cybersecurity Platform threat model',   cls: 'ux' },
    { id: 'qa',  initials: 'QA', name: 'QA Engineer',         role: 'Test Planning & Quality Assurance',    status: 'standby', task: null,                                             cls: 'ba' },
    { id: 'da',  initials: 'DA', name: 'Data Architect',      role: 'Data Modelling & Pipeline Design',     status: 'standby', task: null,                                             cls: 'pm' },
  ]);

  const [activeProjectId, setActiveProjectId] = useState(null);
  const [currentView, setCurrentView] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [newProjectModalOpen, setNewProjectModalOpen] = useState(false);
  const [toasts, setToasts] = useState([]);

  const [notificationsList, setNotificationsList] = useState([]);

  const unreadNotificationsCount = notificationsList.filter(n => n.unread).length;

  // --- Toast Manager ---
  const showToast = (type, message) => {
    const id = 'toast-' + Date.now() + Math.random().toString(36).substr(2, 5);
    setToasts((prev) => [...prev, { id, type, message }]);
  };

  const handleRemoveToast = (id) => {
    setToasts((prev) => prev.filter(t => t.id !== id));
  };

  // --- View switcher ---
  const handleViewChange = (viewId) => {
    setCurrentView(viewId);
    setUserMenuOpen(false);
    setNotificationsOpen(false);
  };

  // --- App functions ---
  const handleOpenProject = (projId) => {
    setActiveProjectId(projId);
    const p = projects.find(x => x.id === projId);
    if (p) showToast('info', `Opening ${p.name}…`);
    handleViewChange('active-project');
  };

  const handleDownloadDocument = (docId) => {
    const doc = documents.find(d => d.id === docId);
    if (doc) showToast('success', `⬇ Downloading ${doc.name}…`);
  };

  const handleDownloadProject = (projId) => {
    const proj = projects.find(p => p.id === projId);
    if (proj) showToast('success', `⬇ Preparing ${proj.name} documents for download…`);
  };

  const handleToggleAgentStatus = (agentId) => {
    setAgents((prev) =>
      prev.map((a) => {
        if (a.id === agentId) {
          const isActive = a.status === 'active';
          showToast(
            isActive ? 'info' : 'success',
            isActive ? `${a.name} set to Standby` : `${a.name} is now Active`
          );
          return {
            ...a,
            status: isActive ? 'standby' : 'active',
            task: isActive ? null : 'Analyzing requirements'
          };
        }
        return a;
      })
    );
  };

  const handleRefresh = () => {
    showToast('info', '🔄 Refreshing dashboard…');
    setTimeout(() => {
      showToast('success', '✅ Dashboard refreshed!');
    }, 1200);
  };

  const handleClearNotifications = () => {
    setNotificationsList((prev) => prev.map(n => ({ ...n, unread: false })));
    showToast('success', '✅ All notifications marked as read');
  };

  const printUserStoriesPdf = (project, stories) => {
    const printWindow = window.open('', '_blank', 'width=900,height=800');
    if (!printWindow) {
      showToast('error', '⚠️ Pop-up blocked! Please allow popups to export the PDF.');
      return;
    }
    
    const storiesHtml = stories.map(s => {
      const acList = s.acceptance_criteria && s.acceptance_criteria.length > 0
        ? `<div class="story-ac">
             <h4>Acceptance Criteria</h4>
             <ul>
               ${s.acceptance_criteria.map(ac => `<li>${ac}</li>`).join('')}
             </ul>
           </div>`
        : '';
        
      const epicBadge = s.epic ? `<span class="badge badge-epic">${s.epic}</span>` : '';
      const spBadge = s.story_points ? `<span class="badge badge-sp">${s.story_points} SP</span>` : '';
      const priorityBadge = `<span class="badge badge-prio ${s.priority || 'medium'}">${(s.priority || 'medium').toUpperCase()}</span>`;
      
      const cleanText = s.text.includes('<strong>') || s.text.includes('<b>')
        ? s.text
        : s.text.replace(/^As an?\s+([^,]+)/i, 'As a <strong>$1</strong>');

      return `
        <div class="story-card">
          <div class="story-header">
            <span class="story-id">${s.id}</span>
            <div class="badges">
              ${epicBadge}
              ${spBadge}
              ${priorityBadge}
            </div>
          </div>
          <div class="story-text">${cleanText}</div>
          ${acList}
        </div>
      `;
    }).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>${project.name} - User Stories Backlog</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
            body {
              font-family: 'Inter', sans-serif;
              color: #1e293b;
              background: #fff;
              padding: 40px;
              line-height: 1.5;
            }
            .header {
              border-bottom: 2px solid #e2e8f0;
              padding-bottom: 20px;
              margin-bottom: 30px;
            }
            .title {
              font-size: 26px;
              font-weight: 700;
              color: #0f172a;
              margin: 0 0 6px 0;
            }
            .subtitle {
              font-size: 14px;
              color: #64748b;
              margin: 0 0 10px 0;
            }
            .meta {
              font-size: 12px;
              color: #94a3b8;
            }
            .story-card {
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              padding: 20px;
              margin-bottom: 20px;
              page-break-inside: avoid;
              background: #f8fafc;
            }
            .story-header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              margin-bottom: 12px;
              border-bottom: 1px dashed #e2e8f0;
              padding-bottom: 8px;
            }
            .story-id {
              font-weight: 700;
              color: #4f8cff;
              font-size: 14px;
              font-family: monospace;
            }
            .badges {
              display: flex;
              gap: 6px;
            }
            .badge {
              font-size: 10px;
              font-weight: 600;
              padding: 3px 8px;
              border-radius: 12px;
              text-transform: uppercase;
            }
            .badge-epic {
              background: #e0f2fe;
              color: #0369a1;
            }
            .badge-sp {
              background: #f1f5f9;
              color: #334155;
            }
            .badge-prio.high {
              background: #ffe4e6;
              color: #be123c;
            }
            .badge-prio.medium {
              background: #fef3c7;
              color: #b45309;
            }
            .badge-prio.low {
              background: #d1fae5;
              color: #047857;
            }
            .story-text {
              font-size: 14.5px;
              color: #1e293b;
              margin-bottom: 14px;
              font-weight: 500;
            }
            .story-text strong {
              color: #0f172a;
              font-weight: 700;
            }
            .story-ac h4 {
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 0.05em;
              color: #475569;
              margin: 0 0 8px 0;
              font-weight: 700;
            }
            .story-ac ul {
              margin: 0;
              padding-left: 18px;
              font-size: 13px;
              color: #334155;
            }
            .story-ac li {
              margin-bottom: 5px;
            }
            @media print {
              body {
                padding: 0;
              }
              .story-card {
                border-color: #cbd5e1;
                background: #fff;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">${project.name}</h1>
            <p class="subtitle">AI-Generated Product Backlog & Detailed User Stories</p>
            <div class="meta">Generated by RequiFlow AI Engine · ${new Date().toLocaleDateString()}</div>
          </div>
          <div class="stories-list">
            ${storiesHtml}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleGenerateStories = async () => {
    showToast('info', '🤖 AI is generating detailed user stories…');
    const p = projects.find(x => x.id === activeProjectId);
    
    // Construct rich context from project data if analyzed
    const payload = {
      requirement: p ? `${p.name}: ${p.desc}` : 'Standard software requirements'
    };
    if (p && p.requirements) {
      payload.project_title = p.name;
      payload.requirements = p.requirements;
      payload.architecture = p.architecture;
      payload.tasks = p.tasks;
    }

    try {
      const response = await fetch('http://localhost:5000/api/generate-user-stories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.user_stories && data.user_stories.length > 0) {
        const prevLength = userStories.length;
        const newStories = data.user_stories.map((story, index) => {
          const finalId = `US-${String(prevLength + index + 1).padStart(3, '0')}`;
          
          let formattedText;
          if (typeof story === 'string') {
            formattedText = story.replace(/^As an?\s+([^,]+)/i, 'As a <strong>$1</strong>');
            return {
              id: finalId,
              projectId: activeProjectId,
              text: formattedText,
              tags: [p ? p.name.split(' ')[0] : 'AI', 'Generated'],
              priority: ['high', 'medium', 'low'][index % 3],
              acceptance_criteria: [],
              story_points: 3,
              epic: 'General'
            };
          } else {
            formattedText = story.text 
              ? story.text.replace(/^As an?\s+([^,]+)/i, 'As a <strong>$1</strong>')
              : `As a <strong>${story.role || 'user'}</strong>, I want to ${story.feature} so that ${story.benefit}`;
              
            return {
              id: finalId,
              projectId: activeProjectId,
              text: formattedText,
              role: story.role,
              feature: story.feature,
              benefit: story.benefit,
              acceptance_criteria: story.acceptance_criteria || [],
              story_points: story.story_points || 3,
              epic: story.epic || 'General',
              tags: [p ? p.name.split(' ')[0] : 'AI', story.epic || 'Generated'],
              priority: story.priority || 'medium'
            };
          }
        });

        // Add dynamically generated stories
        setUserStories((prev) => [...prev, ...newStories]);
        
        // Mark project as having generated stories and trigger progress increment if applicable
        setProjects(prev => prev.map(proj => proj.id === activeProjectId ? {
          ...proj,
          status: 'generated',
          progress: Math.min(proj.progress + 10, 100)
        } : proj));

        showToast('success', `✅ Generated ${newStories.length} detailed user stories!`);
      } else {
        showToast('warning', '⚠️ No user stories returned.');
      }
    } catch (error) {
      console.error('Error generating user stories:', error);
      showToast('error', '❌ Failed to generate user stories from backend.');
    }
  };

  const handleExportDocument = (projId) => {
    const targetProjId = projId || activeProjectId;
    const p = projects.find(x => x.id === targetProjId);
    if (!p) return;

    const stories = userStories.filter(s => s.projectId === targetProjId);
    if (stories.length > 0) {
      showToast('info', '📤 Preparing PDF export for user stories…');
      printUserStoriesPdf(p, stories);
      
      const docName = 'User Stories PDF';
      const exists = documents.some(d => d.projectId === targetProjId && d.name === docName);
      if (!exists) {
        const newDoc = {
          id: 'doc-us-' + Date.now(),
          name: docName,
          fullName: 'Detailed User Stories Specification (PDF)',
          projectId: targetProjId,
          icon: '📄',
          size: '450 KB',
          date: 'Just now'
        };
        setDocuments(prev => [...prev, newDoc]);
      }
      showToast('success', '✅ User stories PDF prepared for printing!');
    } else {
      showToast('warning', '⚠️ No user stories generated yet. Please generate them first.');
    }
  };

  const handleNewProjectSubmit = async (data) => {
    const iconMap = { web: 'ecommerce', mobile: 'fintech', api: 'healthcare', platform: 'edtech', other: 'edtech' };
    const newProjId = 'proj-' + Date.now();
    const newProject = {
      id: newProjId,
      name: data.name,
      desc: data.desc || (data.file ? `Uploaded document: ${data.file.name}` : 'New project'),
      type: data.type,
      status: 'analyzing',
      progress: 10,
      icon: iconMap[data.type] || 'ecommerce',
      updatedLabel: 'Just now',
      stories: 0,
      docs: data.file ? 1 : 0,
      file: data.file ? { name: data.file.name, size: data.file.size } : null,
      questions: [],
      original_requirements: null,
      requirements: null,
      architecture: null,
      tasks: [],
      flowchart: ""
    };

    if (data.file) {
      const formatFileSize = (bytes) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
      };

      const fileExt = data.file.name.split('.').pop().toUpperCase();
      const newDoc = {
        id: 'doc-' + Date.now(),
        name: fileExt,
        fullName: data.file.name,
        projectId: newProjId,
        icon: fileExt === 'PDF' ? '📄' : '📝',
        size: formatFileSize(data.file.size),
        date: 'Just now',
      };
      setDocuments((prev) => [newDoc, ...prev]);
    }

    setProjects((prev) => [newProject, ...prev]);
    setNewProjectModalOpen(false);
    setActiveProjectId(newProjId);
    handleViewChange('active-project');

    if (data.file) {
      showToast('success', `🚀 "${data.name}" created with uploaded document "${data.file.name}"! AI is analyzing…`);
      // Simulate AI analysis delay
      setTimeout(() => {
        setProjects((prev) =>
          prev.map((p) => {
            if (p.id === newProjId) {
              showToast('info', `🤖 AI completed initial document analysis for "${data.name}"`);
              return {
                ...p,
                status: 'analyzed',
                progress: Math.floor(Math.random() * 30) + 30,
                updatedLabel: 'Just now'
              };
            }
            return p;
          })
        );
      }, 2000);
    } else {
      showToast('success', `🚀 "${data.name}" created! Running AI Pipeline…`);
    }

    try {
      const response = await fetch('http://localhost:5000/api/run-orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_text: `${data.name}: ${data.desc}` })
      });

      if (!response.ok) {
        throw new Error('API server error');
      }

      const resData = await response.json();
      if (resData.error) {
        showToast('error', `AI Pipeline failed: ${resData.error}`);
        setProjects(prev => prev.map(p => p.id === newProjId ? { ...p, status: 'failed', progress: 0 } : p));
        return;
      }

      if (resData.questions && resData.questions.length > 0) {
        setProjects(prev => prev.map(p => p.id === newProjId ? {
          ...p,
          status: 'clarifying',
          progress: 40,
          questions: resData.questions,
          original_requirements: {
            project_goal: `${data.name}: ${data.desc}`,
            user_types: [],
            features: [],
            constraints: [],
            risks: [],
            missing_information: resData.questions.map(q => q.question)
          }
        } : p));
        showToast('info', '🔍 Project created. AI generated clarification questions.');
      } else {
        setProjects(prev => prev.map(p => p.id === newProjId ? {
          ...p,
          status: 'analyzed',
          progress: 100,
          requirements: resData.requirements,
          architecture: resData.architecture,
          tasks: resData.tasks,
          flowchart: resData.flowchart
        } : p));
        showToast('success', `✅ AI analysis complete for "${data.name}"!`);
      }
    } catch (error) {
      console.error(error);
      showToast('error', '❌ Failed to run AI pipeline.');
      setProjects(prev => prev.map(p => p.id === newProjId ? { ...p, status: 'failed', progress: 0 } : p));
    }
  };

  const handleClarificationSubmit = async (projectId, answersData) => {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, status: 'analyzing', progress: 50 } : p));
    showToast('info', '🤖 Re-running AI pipeline with your clarifications…');

    const project = projects.find(p => p.id === projectId);
    if (!project) return;

    const formattedAnswers = {
      answers: project.questions.map(q => ({
        question_id: q.id,
        answer: answersData[q.id] || "No answer provided."
      }))
    };

    try {
      const response = await fetch('http://localhost:5000/api/run-orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          original_requirements: project.original_requirements,
          user_answers: formattedAnswers
        })
      });

      if (!response.ok) {
        throw new Error('API server error');
      }

      const resData = await response.json();
      if (resData.error) {
        showToast('error', `AI Pipeline failed: ${resData.error}`);
        setProjects(prev => prev.map(p => p.id === projectId ? { ...p, status: 'failed', progress: 0 } : p));
        return;
      }

      if (resData.questions && resData.questions.length > 0) {
        setProjects(prev => prev.map(p => p.id === projectId ? {
          ...p,
          status: 'clarifying',
          progress: 60,
          questions: resData.questions,
          original_requirements: resData.requirements || project.original_requirements
        } : p));
        showToast('info', '🔍 Additional clarification questions generated.');
      } else {
        setProjects(prev => prev.map(p => p.id === projectId ? {
          ...p,
          status: 'analyzed',
          progress: 100,
          requirements: resData.requirements,
          architecture: resData.architecture,
          tasks: resData.tasks,
          flowchart: resData.flowchart
        } : p));
        showToast('success', `✅ AI analysis complete for "${project.name}"!`);
      }
    } catch (error) {
      console.error(error);
      showToast('error', '❌ Failed to submit clarifications to backend.');
      setProjects(prev => prev.map(p => p.id === projectId ? { ...p, status: 'failed', progress: 0 } : p));
    }
  };

  useEffect(() => {
    localStorage.setItem('requiflow_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('requiflow_user_stories', JSON.stringify(userStories));
  }, [userStories]);

  useEffect(() => {
    localStorage.setItem('requiflow_documents', JSON.stringify(documents));
  }, [documents]);

  // --- Outside click handlers ---
  useEffect(() => {
    const handleOutsideClick = (e) => {
      const notifPanel = document.getElementById('notifications-panel');
      const notifBtn = document.getElementById('notifications-btn');
      const userMenu = document.getElementById('user-dropdown');
      const userBtn = document.getElementById('user-profile-btn');

      if (notifPanel && notifBtn && !notifPanel.contains(e.target) && !notifBtn.contains(e.target)) {
        setNotificationsOpen(false);
      }
      if (userMenu && userBtn && !userMenu.contains(e.target) && !userBtn.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };

    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  // --- View renderer mapping ---
  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            projects={projects}
            userStories={userStories}
            documents={documents}
            agents={agents}
            onViewChange={handleViewChange}
            onOpenProject={handleOpenProject}
            onDownloadProject={handleDownloadProject}
            onToggleAgentStatus={handleToggleAgentStatus}
          />
        );
      case 'projects':
        return (
          <ProjectsView
            projects={projects}
            searchQuery={searchQuery}
            onOpenProject={handleOpenProject}
            onNewProjectClick={() => setNewProjectModalOpen(true)}
          />
        );
      case 'active-project':
        return (
          <ActiveProjectView
            projects={projects}
            activeProjectId={activeProjectId}
            userStories={userStories}
            documents={documents}
            onGenerateStories={handleGenerateStories}
            onExportDocument={handleExportDocument}
            onDownloadDocument={handleDownloadDocument}
            onViewChange={handleViewChange}
            onClarificationSubmit={handleClarificationSubmit}
          />
        );
      case 'user-stories':
        return (
          <UserStoriesView
            userStories={userStories}
            onGenerateStories={handleGenerateStories}
          />
        );
      case 'documents':
        return (
          <DocumentsView
            documents={documents}
            projects={projects}
            onExportDocument={handleExportDocument}
            onDownloadDocument={handleDownloadDocument}
          />
        );
      case 'ai-agents':
        return (
          <AiAgentsView
            agents={agents}
            onToggleAgentStatus={handleToggleAgentStatus}
          />
        );
      case 'settings':
        return <SettingsView onShowToast={showToast} />;
      default:
        return (
          <DashboardView
            projects={projects}
            userStories={userStories}
            documents={documents}
            agents={agents}
            onViewChange={handleViewChange}
            onOpenProject={handleOpenProject}
            onDownloadProject={handleDownloadProject}
            onToggleAgentStatus={handleToggleAgentStatus}
          />
        );
    }
  };

  const titles = {
    dashboard: 'Dashboard',
    projects: 'Projects',
    'active-project': 'Active Project',
    'user-stories': 'User Stories',
    documents: 'Documents',
    'ai-agents': 'AI Agents',
    settings: 'Settings',
  };
  const pageTitle = titles[currentView] || 'Dashboard';

  const DashboardContent = () => (
    <div className="app-shell">
      {/* Sidebar */}
      <Sidebar
        currentView={currentView}
        onViewChange={handleViewChange}
        projectsCount={projects.length}
        userMenuOpen={userMenuOpen}
        setUserMenuOpen={setUserMenuOpen}
        closeNotifications={() => setNotificationsOpen(false)}
      />

      {/* Main panel */}
      <main className="main-content" id="main-content">
        <Topbar
          pageTitle={pageTitle}
          searchVal={searchQuery}
          onSearchChange={setSearchQuery}
          onRefresh={handleRefresh}
          notificationsCount={unreadNotificationsCount}
          onNotificationsToggle={() => {
            setNotificationsOpen(!notificationsOpen);
            setUserMenuOpen(false);
          }}
          onNewProjectClick={() => setNewProjectModalOpen(true)}
        />

        <NotificationsPanel
          isOpen={notificationsOpen}
          notificationsList={notificationsList}
          onClearAll={handleClearNotifications}
        />

        {/* View renderer */}
        {renderView()}
      </main>

      {/* New Project Modal */}
      <NewProjectModal
        isOpen={newProjectModalOpen}
        onClose={() => setNewProjectModalOpen(false)}
        onSubmit={handleNewProjectSubmit}
      />

      {/* Toast Alert list */}
      <ToastContainer toasts={toasts} onRemoveToast={handleRemoveToast} />
    </div>
  );

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/auth" element={<AuthView />} />
      <Route path="/verify-email/:token" element={<VerifyEmailView />} />
      <Route path="/dashboard" element={<DashboardContent />} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

export default App;
