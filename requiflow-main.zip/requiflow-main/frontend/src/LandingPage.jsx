import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

/* ─────────────────────────────────────────────
   Hero typing animation
───────────────────────────────────────────── */
function TypedText({ phrases }) {
  const [phrase, setPhrase] = useState(0);
  const [text, setText] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = phrases[phrase];
    let t;
    if (!deleting && text === current) {
      t = setTimeout(() => setDeleting(true), 2200);
    } else if (deleting && text === '') {
      setDeleting(false);
      setPhrase((p) => (p + 1) % phrases.length);
    } else {
      t = setTimeout(() => setText(
        deleting ? current.slice(0, text.length - 1) : current.slice(0, text.length + 1)
      ), deleting ? 30 : 55);
    }
    return () => clearTimeout(t);
  }, [text, deleting, phrase, phrases]);

  return <span className="lp-typed">{text}<span className="lp-cursor">|</span></span>;
}

/* ─────────────────────────────────────────────
   Scroll reveal hook
───────────────────────────────────────────── */
function useReveal(threshold = 0.15) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
}

/* ─────────────────────────────────────────────
   Advanced Feature Visualizations
───────────────────────────────────────────── */
const SrsVisualizer = ({ accent }) => (
  <div className="fv-adv-srs">
    <div className="fv-srs-doc" style={{ boxShadow: `0 20px 50px -10px ${accent}` }}>
      <div className="fv-srs-header" />
      {[...Array(6)].map((_, i) => (
        <div key={i} className="fv-srs-line" style={{ animationDelay: `${i * 0.15}s` }} />
      ))}
      <div className="fv-srs-glow" style={{ background: accent }} />
    </div>
    <div className="fv-srs-particles">
      {[...Array(12)].map((_, i) => <div key={i} className="fv-srs-particle" style={{ background: accent, animationDelay: `${Math.random() * 2}s`, left: `${Math.random() * 100}%` }} />)}
    </div>
  </div>
);

const AgentsVisualizer = ({ accent }) => (
  <div className="fv-adv-agents-chat">
    <div className="fv-chat-msg fv-msg-left">
      <div className="fv-chat-avatar">BA</div>
      <div className="fv-chat-bubble">Scope & Rules parsed</div>
    </div>
    <div className="fv-chat-msg fv-msg-right">
      <div className="fv-chat-bubble" style={{ borderColor: accent, color: accent }}>Architecture mapped</div>
      <div className="fv-chat-avatar" style={{ color: accent, borderColor: accent }}>SA</div>
    </div>
    <div className="fv-chat-msg fv-msg-left" style={{ animationDelay: '2.5s' }}>
      <div className="fv-chat-avatar">QA</div>
      <div className="fv-chat-bubble">18 Test cases generated</div>
    </div>
    <div className="fv-chat-msg fv-msg-right" style={{ animationDelay: '3.5s' }}>
      <div className="fv-chat-bubble" style={{ background: accent, color: '#000', borderColor: accent }}>Ready for Jira sync</div>
      <div className="fv-chat-avatar" style={{ background: accent, color: '#000', borderColor: accent }}>PM</div>
    </div>
  </div>
);

const BddVisualizer = ({ accent }) => (
  <div className="fv-adv-bdd" style={{ borderColor: accent, boxShadow: `0 10px 40px -15px ${accent}` }}>
    <div className="fv-bdd-header">
      <div className="fv-bdd-dots"><span className="fv-dot-r"/><span className="fv-dot-y"/><span className="fv-dot-g"/></div>
      <div className="fv-bdd-title">auth.feature</div>
    </div>
    <div className="fv-bdd-body">
      <div className="fv-bdd-line"><span className="fv-bdd-kw">Feature:</span> User Auth</div>
      <div className="fv-bdd-line"><span className="fv-bdd-kw">Scenario:</span> Login</div>
      <div className="fv-bdd-line fv-bdd-type-1"><span className="fv-bdd-kw" style={{color:accent}}>Given</span> user is on login</div>
      <div className="fv-bdd-line fv-bdd-type-2"><span className="fv-bdd-kw" style={{color:accent}}>When</span> they enter details</div>
      <div className="fv-bdd-line fv-bdd-type-3"><span className="fv-bdd-kw" style={{color:accent}}>Then</span> access granted</div>
    </div>
  </div>
);

const SecurityVisualizer = ({ accent }) => (
  <div className="fv-adv-sec">
    <div className="fv-sec-hex" />
    <svg className="fv-sec-shield" viewBox="0 0 100 100" fill="none" stroke={accent} strokeWidth="2.5">
      <path d="M50 5 L90 20 L90 50 C90 75 50 95 50 95 C50 95 10 75 10 50 L10 20 Z" className="fv-sec-path" />
    </svg>
    <div className="fv-sec-radar" style={{ borderColor: accent }}>
      <div className="fv-sec-sweep" style={{ background: `conic-gradient(from 0deg, transparent 70%, ${accent} 100%)` }} />
    </div>
    <div className="fv-sec-status" style={{ color: accent, textShadow: `0 0 10px ${accent}` }}>SECURE</div>
  </div>
);

const ParseVisualizer = ({ accent }) => (
  <div className="fv-adv-parse">
    <div className="fv-parse-input">
      <div className="fv-parse-doc-icon" style={{ borderColor: accent }} />
      <div className="fv-parse-scanline" style={{ background: accent, boxShadow: `0 0 10px ${accent}` }} />
    </div>
    <div className="fv-parse-arrow" style={{ color: accent }}>→</div>
    <div className="fv-parse-output" style={{ borderColor: accent, background: `radial-gradient(circle at top right, ${accent}22, transparent)` }}>
      <div className="fv-parse-node">{"{"}</div>
      <div className="fv-parse-node" style={{ paddingLeft: '12px' }}>"data": <span className="fv-parse-val">"..."</span>,</div>
      <div className="fv-parse-node" style={{ paddingLeft: '12px' }}>"status": <span className="fv-parse-val">200</span></div>
      <div className="fv-parse-node">{"}"}</div>
    </div>
  </div>
);

const DashboardVisualizer = ({ accent }) => (
  <div className="fv-adv-dash">
    <div className="fv-dash-grid">
      {[...Array(4)].map((_, i) => <div key={i} className="fv-dash-grid-line" />)}
    </div>
    <div className="fv-dash-bars">
      {[40, 75, 55, 95, 65].map((h, i) => (
        <div key={i} className="fv-dash-bar-3d" style={{ height: `${h}%`, backgroundColor: accent, animationDelay: `${i * 0.15}s` }}>
          <div className="fv-dash-bar-top" />
        </div>
      ))}
    </div>
    <svg className="fv-dash-line-svg" viewBox="0 0 200 100" preserveAspectRatio="none">
      <path d="M0 70 Q 40 10 100 50 T 200 20" fill="none" stroke="#fff" strokeWidth="2.5" className="fv-dash-line-path" />
    </svg>
    <div className="fv-dash-tooltip" style={{ borderColor: accent, color: accent, boxShadow: `0 0 15px ${accent}44` }}>+42%</div>
  </div>
);

function FeatureVisualizer({ index, accent }) {
  switch (index) {
    case 0: return <SrsVisualizer accent={accent} />;
    case 1: return <AgentsVisualizer accent={accent} />;
    case 2: return <BddVisualizer accent={accent} />;
    case 3: return <SecurityVisualizer accent={accent} />;
    case 4: return <ParseVisualizer accent={accent} />;
    case 5: return <DashboardVisualizer accent={accent} />;
    default: return null;
  }
}

/* ─────────────────────────────────────────────
   Interactive Feature Tabs
───────────────────────────────────────────── */
function InteractiveFeatureTabs({ features }) {
  const [activeIdx, setActiveIdx] = useState(0);
  const activeFeature = features[activeIdx];

  return (
    <div className="lp-feature-tabs-container">
      <div className="lp-feature-tabs-menu">
        {features.map((f, i) => (
          <div 
            key={i} 
            className={`lp-feature-tab ${i === activeIdx ? 'active' : ''}`}
            onClick={() => setActiveIdx(i)}
          >
            <div className="lp-feature-tab-title">{f.title}</div>
          </div>
        ))}
      </div>
      <div className="lp-feature-tabs-content">
        <div className="lp-feature-display" key={activeIdx}>
          <div className="lp-feature-display-glow" style={{ background: activeFeature.accent }} />
          <div className="lp-feature-display-text">
            <h3 className="lp-feature-display-title">{activeFeature.title}</h3>
            <p className="lp-feature-display-desc">{activeFeature.desc}</p>
          </div>
          <div className="lp-feature-display-visual">
            <FeatureVisualizer index={activeIdx} accent={activeFeature.accent} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   FLOATING AI COMMAND CENTER (Simplified & Clean)
───────────────────────────────────────────── */
function FloatingCommandCenter() {
  const [collapsed, setCollapsed] = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  
  const STEPS = [
    { label: "Ingesting Requirements.pdf", duration: 1500 },
    { label: "BA Agent extracting rules...", duration: 2000 },
    { label: "Security Agent checking OWASP...", duration: 2500 },
    { label: "Generating BDD criteria...", duration: 2000 },
    { label: "Formatting 18 User Stories...", duration: 1500 },
    { label: "Ready for Jira sync.", duration: 3000 },
  ];

  useEffect(() => {
    if (collapsed) return;
    const t = setTimeout(() => {
      setStepIdx(s => (s + 1) % STEPS.length);
    }, STEPS[stepIdx].duration);
    return () => clearTimeout(t);
  }, [stepIdx, collapsed]);

  return (
    <div className={`lp-acc-simple ${collapsed ? 'lp-acc-simple--collapsed' : ''}`}>
      <div className="lp-acc-simple-header" onClick={() => setCollapsed(c => !c)}>
        <div className="lp-acc-simple-title">
          <div className="lp-acc-simple-dot" />
          RequiFlow AI Engine
        </div>
        <div className="lp-acc-simple-toggle">
          {collapsed ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="18 15 12 9 6 15"/></svg>
          )}
        </div>
      </div>
      {!collapsed && (
        <div className="lp-acc-simple-body">
          {STEPS.map((step, i) => {
            const isPast = i < stepIdx;
            const isActive = i === stepIdx;
            const isFuture = i > stepIdx;
            
            return (
              <div key={i} className={`lp-acc-step ${isActive ? 'lp-acc-step--active' : ''} ${isPast ? 'lp-acc-step--past' : ''} ${isFuture ? 'lp-acc-step--future' : ''}`}>
                <div className="lp-acc-step-icon">
                  {isPast ? (
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                  ) : isActive ? (
                    <div className="lp-acc-spinner" />
                  ) : (
                    <div className="lp-acc-circle" />
                  )}
                </div>
                <div className="lp-acc-step-label">{step.label}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────
   AI CORE PARALLAX — 3D Geometric Domain Element
───────────────────────────────────────────── */
function AICoreParallax() {
  const [scroll, setScroll] = useState(0);

  useEffect(() => {
    const root = document.querySelector('.lp-root');
    if (!root) return;
    
    let frameId;
    const onScroll = () => {
      if (!frameId) frameId = requestAnimationFrame(() => {
        setScroll(root.scrollTop);
        frameId = null;
      });
    };
    
    root.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    
    return () => {
      root.removeEventListener('scroll', onScroll);
      if (frameId) cancelAnimationFrame(frameId);
    };
  }, []);

  const opacity = Math.min(1, Math.max(0, (scroll - 300) / 400));
  const y = Math.sin(scroll * 0.003) * 60; 
  const rot1 = scroll * 0.15;
  const rot2 = scroll * -0.1 + 45;
  const rot3 = scroll * 0.2 + 90;
  const scale = Math.min(1.8, 1 + (scroll * 0.0004));

  return (
    <div className="lp-ai-core" style={{ transform: `translateY(${y}px)`, opacity }}>
      <div className="lp-core-container" style={{ transform: `scale(${scale})` }}>
        <div className="lp-core-ring lp-core-ring-1" style={{ transform: `rotateX(65deg) rotateY(${rot1}deg)` }} />
        <div className="lp-core-ring lp-core-ring-2" style={{ transform: `rotateX(45deg) rotateY(${rot2}deg)` }} />
        <div className="lp-core-ring lp-core-ring-3" style={{ transform: `rotateX(75deg) rotateY(${rot3}deg)` }} />
        <div className="lp-core-center">
          <div className="lp-core-glow" style={{ transform: `scale(${1 + Math.sin(scroll * 0.01) * 0.2})` }} />
        </div>
      </div>
    </div>
  );
}


/* ─────────────────────────────────────────────
   MAIN LANDING PAGE
───────────────────────────────────────────── */
export default function LandingPage() {
  const containerRef = useRef(null);
  const navRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    
    let frameId;
    const onScroll = () => {
      if (navRef.current) navRef.current.classList.toggle('lp-nav-solid', el.scrollTop > 40);
      if (!frameId) frameId = requestAnimationFrame(() => {
        frameId = null;
      });
    };

    el.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', onScroll);
      if (frameId) cancelAnimationFrame(frameId);
    };
  }, []);

  const scrollTo = (id) => {
    const container = containerRef.current;
    const el = document.getElementById(id);
    if (!el || !container) return;
    const top = el.getBoundingClientRect().top + container.scrollTop - container.getBoundingClientRect().top;
    container.scrollTo({ top, behavior: 'smooth' });
  };

  const features = [
    { icon: '⚡', title: 'Instant SRS & BRD', desc: 'Transform raw notes or uploaded PDFs into full SRS and BRD documents in under 60 seconds. No manual formatting needed.', accent: 'rgba(59,158,255,0.18)', delay: 0 },
    { icon: '🤖', title: '5 Specialized AI Agents', desc: 'BA, Architect, Security Analyst, PM, and QA agents collaborate in parallel to ensure complete coverage.', accent: 'rgba(167,139,250,0.18)', delay: 100 },
    { icon: '🎯', title: 'BDD Acceptance Criteria', desc: 'Every user story is automatically enriched with Given-When-Then criteria for direct developer handoff.', accent: 'rgba(62,207,142,0.18)', delay: 200 },
    { icon: '🔒', title: 'Security & Compliance', desc: 'Auto-review for GDPR risks & OWASP Top 10 vulnerabilities, ensuring security from day one.', accent: 'rgba(255,179,66,0.18)', delay: 300 },
    { icon: '📄', title: 'Native File Parsing', desc: 'Drag & drop PDF, DOC, or DOCX. The parser extracts headings, tables, and scope automatically without losing context.', accent: 'rgba(0,212,255,0.18)', delay: 400 },
    { icon: '📊', title: 'Live Project Dashboard', desc: 'Track requirements, approvals, story counts, and exports from one real-time dark-mode cockpit.', accent: 'rgba(255,107,107,0.18)', delay: 500 },
  ];

  const [ctaRef, ctaVisible] = useReveal(0.2);
  const [featHeadRef, featHeadVisible] = useReveal(0.2);

  return (
    <div className="lp-root" ref={containerRef}>
      
      <AICoreParallax />

      <nav className="lp-nav" ref={navRef}>
        <div className="lp-nav-inner">
          <img src="/logo.png" alt="RequiFlow" className="lp-nav-logo-img" />
          <div className="lp-nav-links">
            <button onClick={() => scrollTo('lp-features')}>Features</button>
            <button onClick={() => scrollTo('lp-cta')}>Get Started</button>
          </div>
          <button className="lp-btn-primary" onClick={() => navigate('/auth')}>
            Sign In / Sign Up
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
            </svg>
          </button>
        </div>
      </nav>

      <section className="lp-hero" id="lp-hero">
        <div className="lp-grid-bg" />
        {[
          { s:3, l:'10%', t:'72%', dur:'6s',   del:'0s'   },
          { s:2, l:'24%', t:'82%', dur:'8s',   del:'1.5s' },
          { s:4, l:'44%', t:'76%', dur:'7s',   del:'0.5s' },
          { s:2, l:'62%', t:'86%', dur:'9s',   del:'2s'   },
          { s:3, l:'79%', t:'70%', dur:'6.5s', del:'1s'   },
          { s:2, l:'90%', t:'80%', dur:'8.5s', del:'3s'   },
        ].map((p, i) => (
          <div key={i} className="lp-particle" style={{ width: p.s, height: p.s, left: p.l, top: p.t, animationDuration: p.dur, animationDelay: p.del }} />
        ))}

        <div className="lp-hero-inner">
          <div className="lp-badge">
            <span className="lp-badge-dot" />
            AI-Powered Requirements Engineering
          </div>
          <h1 className="lp-h1">
            <span className="lp-h1-static">Turn requirements into</span><br />
            <TypedText phrases={['user stories instantly.', 'SRS docs in 60 seconds.', 'sprint-ready backlogs.', 'developer-ready specs.']} />
          </h1>
          <p className="lp-sub">
            Upload a PDF, paste notes, or describe your vision — RequiFlow's AI agents handle the rest. No templates. No manual effort.
          </p>
          <div className="lp-ctas">
            <button className="lp-btn-primary lp-btn-large" onClick={() => navigate('/auth')}>
              Start for Free
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
              </svg>
            </button>
          </div>
          <div className="lp-chips">
            <div className="lp-chip" style={{ borderColor: 'rgba(59,158,255,0.28)' }}>
              <span className="lp-chip-dot" style={{ background: '#3b9eff', boxShadow: '0 0 8px #3b9eff' }} />
              <span style={{ color: '#3b9eff' }}>42 User Stories Generated</span>
            </div>
            <div className="lp-chip" style={{ borderColor: 'rgba(62,207,142,0.28)' }}>
              <span className="lp-chip-dot" style={{ background: '#3ecf8e', boxShadow: '0 0 8px #3ecf8e' }} />
              <span style={{ color: '#3ecf8e' }}>5 AI Agents Live</span>
            </div>
            <div className="lp-chip" style={{ borderColor: 'rgba(167,139,250,0.28)' }}>
              <span className="lp-chip-dot" style={{ background: '#a78bfa', boxShadow: '0 0 8px #a78bfa' }} />
              <span style={{ color: '#a78bfa' }}>4 Active Projects</span>
            </div>
          </div>
        </div>

        <div className="lp-scroll-hint" onClick={() => scrollTo('lp-features')}>
          <span>Scroll to explore</span>
          <div className="lp-scroll-arrow">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>
            </svg>
          </div>
        </div>
      </section>

      <section className="lp-features-section" id="lp-features">
        <div className="lp-section-inner">
          <div ref={featHeadRef} className={`lp-fade-up ${featHeadVisible ? 'lp-revealed' : ''}`}>
            <div className="lp-section-eyebrow">CORE FEATURES</div>
            <h2 className="lp-section-h2">
              Everything your BA team needs,<br />
              <span className="lp-h2-accent">in one intelligent platform</span>
            </h2>
          </div>
          <InteractiveFeatureTabs features={features} />
        </div>
      </section>

      <section className="lp-cta-section" id="lp-cta">
        <div ref={ctaRef} className={`lp-cta-inner ${ctaVisible ? 'lp-revealed' : ''}`}>
          <div className="lp-cta-orb" />
          <div className="lp-section-eyebrow">READY TO SHIP?</div>
          <h2 className="lp-cta-title">Ready to Automate Your Requirements?</h2>
          <p className="lp-cta-desc">
            Join forward-thinking product teams shipping 10x faster with AI-generated specifications and automated compliance.
          </p>
          <button className="lp-btn-primary lp-btn-large" onClick={() => navigate('/auth')}>
            Get Started Now
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </button>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="lp-footer-inner">
          <img src="/logo.png" alt="RequiFlow" className="lp-footer-logo" />
          <p className="lp-footer-copy">© 2026 RequiFlow · AI Requirements Platform</p>
          <div className="lp-footer-links">
            <button onClick={() => scrollTo('lp-features')}>Features</button>
            <button onClick={() => navigate('/auth')}>Launch App</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
